#include<iostream>
#include<algorithm>
#include<cstring>
#include<cstdio>
#include<bitset>
#include<random>
#include<cmath>
#include<ctime>
#include<queue>
#include<map>
#include<set>

#define int long long
#define fi first
#define se second
#define max Max
#define min Min
#define abs Abs
#define lc (x<<1)
#define rc (x<<1|1)
#define mid ((l+r)>>1)
#define pb(x) push_back(x)
#define lowbit(x) ((x)&(-(x)))
#define fan(x) ((((x)-1)^1)+1)
#define mp(x,y) make_pair(x,y)
#define clr(f,n) memset(f,0,sizeof(int)*(n))
#define cpy(f,g,n) memcpy(f,g,sizeof(int)*(n))
#define SZ(x) ((int)(x.size()))
#define INF 0x3f3f3f3f

using namespace std;

inline int read()
{
	int ans=0,f=1;
	char c=getchar();
	while(c>'9'||c<'0'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9'){ans=(ans<<1)+(ans<<3)+c-'0';c=getchar();}
	return ans*f;
}

inline void write(int x)
{
	if(x<0) putchar('-'),x=-x;
	if(x/10) write(x/10);
	putchar((char)(x%10)+'0');
}

template<typename T>inline T Abs(T a){return a>0?a:-a;};
template<typename T,typename TT>inline T Min(T a,TT b){return a<b?a:b;}
template<typename T,typename TT> inline T Max(T a,TT b){return a<b?b:a;}

const int N=5e5+5;
int n,m,q,a[N],fa[N],ans[N];

struct Edge
{
	int u,v,w;
	bool operator < (const Edge &x)const
	{
		return w>x.w;
	}
}e[N];

inline int find(int x)
{
	return fa[x]==x?x:fa[x]=find(fa[x]);
}

pair<int,int> qus[N];

signed main()
{
	freopen("add.in","r",stdin);
	freopen("add.out","w",stdout);
	n=read();m=read();q=read();
	for(int i=1;i<=n;++i)
		a[i]=read();
	for(int i=1;i<=m;++i)
	{
		e[i].u=read();
		e[i].v=read();
		e[i].w=read();
	}
	sort(e+1,e+1+m);
	for(int i=1;i<=q;++i)
		qus[i]=mp(read(),i);
	sort(qus+1,qus+1+q);
	int cnt=n,mn=INF,res=0;
	for(int i=1;i<=n;++i)
	{
		fa[i]=i;res+=a[i];
		mn=min(mn,a[i]);
	}
	int now=1;
	for(int i=q;i>=1;--i)
	{
		while(now<=m&&e[now].w>=qus[i].fi)
		{
			int u=find(e[now].u);
			int v=find(e[now].v);++now;
			if(u!=v)
			{
				--cnt;res-=a[u]+a[v];
				a[u]=min(a[u],a[v]);fa[v]=u;
				res+=a[u];
			}
		}
		ans[qus[i].se]=(cnt-2)*mn+res;
	}
	for(int i=1;i<=q;++i)
		write(ans[i]),puts("");
	return 0;
}

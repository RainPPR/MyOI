#include<iostream>
#include<algorithm>
#include<cstring>
#include<cstdio>
#include<bitset>
#include<random>
#include<cmath>
#include<ctime>
#include<queue>
#include<map>
#include<set>

#define int long long
#define fi first
#define se second
#define max Max
#define min Min
#define abs Abs
#define lc (x<<1)
#define rc (x<<1|1)
#define mid ((l+r)>>1)
#define pb(x) push_back(x)
#define lowbit(x) ((x)&(-(x)))
#define fan(x) ((((x)-1)^1)+1)
#define mp(x,y) make_pair(x,y)
#define clr(f,n) memset(f,0,sizeof(int)*(n))
#define cpy(f,g,n) memcpy(f,g,sizeof(int)*(n))
#define SZ(x) ((int)(x.size()))
#define INF 0x3f3f3f3f

using namespace std;

inline int read()
{
	int ans=0,f=1;
	char c=getchar();
	while(c>'9'||c<'0'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9'){ans=(ans<<1)+(ans<<3)+c-'0';c=getchar();}
	return ans*f;
}

inline void write(int x)
{
	if(x<0) putchar('-'),x=-x;
	if(x/10) write(x/10);
	putchar((char)(x%10)+'0');
}

template<typename T>inline T Abs(T a){return a>0?a:-a;};
template<typename T,typename TT>inline T Min(T a,TT b){return a<b?a:b;}
template<typename T,typename TT> inline T Max(T a,TT b){return a<b?b:a;}

const int N=1e5+5,M=1e6+5,K=1e6;
int n,q,a[N],b[N],ans,m1[N],m2[N],Ans[N];

struct Node
{
	int x,v,id;
	bool operator < (const Node &p)const
	{
		return x>p.x;
	}
}qus[N];

struct sg1
{
	int val[M<<2],cnt[M<<2];
	void pushup(int x)
	{
		val[x]=val[lc]+val[rc];
		cnt[x]=cnt[lc]+cnt[rc];
	}
	void update(int x,int l,int r,int v)
	{
		if(l==r)
		{
			val[x]+=v;
			cnt[x]++;
			return;
		}
		if(v<=mid) update(lc,l,mid,v);
		else update(rc,mid+1,r,v);
		pushup(x);
	}
	int query1(int x,int l,int r,int k)
	{
		if(l==r) return l*k;
		if(k<=cnt[rc]) return query1(rc,mid+1,r,k);
		else return val[rc]+query1(lc,l,mid,k-cnt[rc]);
	}
	int query2(int x,int l,int r,int k)
	{
		if(l==r) return l;
		if(k<=cnt[rc]) return query2(rc,mid+1,r,k);
		else return query2(lc,l,mid,k-cnt[rc]);
	}
}t0;

struct sg2
{
	int val[M<<2],cnt[M<<2];
	void pushup(int x)
	{
		val[x]=val[lc]+val[rc];
		cnt[x]=cnt[lc]+cnt[rc];
	}
	void update(int x,int l,int r,int v)
	{
		if(l==r)
		{
			val[x]+=v;
			cnt[x]++;
			return;
		}
		if(v<=mid) update(lc,l,mid,v);
		else update(rc,mid+1,r,v);
		pushup(x);
	}
	int query1(int x,int l,int r,int p)
	{
		if(l==r) return cnt[x];
		if(p<=mid) return query1(lc,l,mid,p);
		else return cnt[lc]+query1(rc,mid+1,r,p);
	}
	int query2(int x,int l,int r,int L,int R)
	{
		if(L<=l&&r<=R) return val[x];
		int res=0;
		if(L<=mid) res+=query2(lc,l,mid,L,R);
		if(mid+1<=R) res+=query2(rc,mid+1,r,L,R);
		return res;
	}
}t1,t2;

signed main()
{
	freopen("operate.in","r",stdin);
	freopen("operate.out","w",stdout);
	n=read();q=read();
	for(int i=1;i<=n;++i)
		a[i]=read();
	for(int i=1;i<=n;++i)
	{
		b[i]=read();
		t0.update(1,1,K,a[i]);
		ans+=t0.query1(1,1,K,b[i]);
		m1[i]=t0.query2(1,1,K,b[i]);
		if(b[i]==i) m2[i]=0;
		else m2[i]=t0.query2(1,1,K,b[i]+1);
	}
	for(int i=1;i<=q;++i)
	{
		qus[i].x=read();
		qus[i].v=read();
		qus[i].id=i;
	}
	sort(qus+1,qus+1+q);
	int now=0;
	for(int i=n;i>=1;--i)
	{
		t1.update(1,1,K,m1[i]);
		t2.update(1,0,K,m2[i]);
		while(now<q&&qus[now+1].x==i)
		{
			++now;int res=ans;
			int x=qus[now].x,v=qus[now].v;
			if(v>a[x])
			{
				res-=t1.query1(1,1,K,a[x])*a[x];
				res+=t1.query1(1,1,K,v)*v;
				res-=t1.query2(1,1,K,a[x]+1,v);
			}
			else if(v<a[x])
			{
				res-=t2.query1(1,0,K,a[x]-1)*a[x];
				res+=t2.query1(1,0,K,v-1)*v;
				res+=t2.query2(1,0,K,v,a[x]-1);
			}
			Ans[qus[now].id]=res;
		}
	}
	for(int i=1;i<=q;++i)
		write(Ans[i]),puts("");
	return 0;
}

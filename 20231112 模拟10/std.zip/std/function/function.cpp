#include<iostream>
#include<algorithm>
#include<cstring>
#include<cstdio>
#include<bitset>
#include<random>
#include<cmath>
#include<ctime>
#include<queue>
#include<map>
#include<set>

#define fi first
#define se second
#define max Max
#define min Min
#define abs Abs
#define lc (x<<1)
#define rc (x<<1|1)
#define mid ((l+r)>>1)
#define pb(x) push_back(x)
#define lowbit(x) ((x)&(-(x)))
#define fan(x) ((((x)-1)^1)+1)
#define mp(x,y) make_pair(x,y)
#define clr(f,n) memset(f,0,sizeof(int)*(n))
#define cpy(f,g,n) memcpy(f,g,sizeof(int)*(n))
#define SZ(x) ((int)(x.size()))
#define INF 0x3f3f3f3f

using namespace std;

inline int read()
{
	int ans=0,f=1;
	char c=getchar();
	while(c>'9'||c<'0'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9'){ans=(ans<<1)+(ans<<3)+c-'0';c=getchar();}
	return ans*f;
}

inline void write(int x)
{
	if(x<0) putchar('-'),x=-x;
	if(x/10) write(x/10);
	putchar((char)(x%10)+'0');
}

template<typename T>inline T Abs(T a){return a>0?a:-a;};
template<typename T,typename TT>inline T Min(T a,TT b){return a<b?a:b;}
template<typename T,typename TT> inline T Max(T a,TT b){return a<b?b:a;}

const int N=3e5+5;
int n,m,q,a[N],b[N],Ans[N];

set<int> sg;

struct Qus
{
	int l,r,id;
}c[N],rv[N];

vector<int> hv[N];

inline void flip(int x)
{
	if(x>1)
	{
		if(b[x]==b[x-1])
			sg.erase(x-1);
		else sg.insert(x-1);
	}
	if(x<n)
	{
		if(b[x]==b[x+1])
			sg.erase(x);
		else sg.insert(x);
	}
	b[x]^=1;
}

inline void Flip(int x)
{
	for(auto i:hv[x])
		flip(i);
}

inline bool check(int l,int r)
{
	auto it=sg.lower_bound(mid);
	int p1=*prev(it)+1,p2=*it;
	if(p1<=l&&p2>=r) return b[l];
	if(mid-p1<p2-mid) return b[p1];
	else return b[p2];
}

int lim;

void solve(int l,int r,int L,int R)
{
	if(L>R) return;
	if(l==r)
	{
		for(int i=L;i<=R;++i)
			Ans[c[i].id]=l;
		return;
	}
	while(lim>mid+1)
		Flip(--lim);
	while(lim<mid+1)
		Flip(lim++);
	int top=0,now=L,MID=-1;
	for(int i=L;i<=R;++i)
		if(check(c[i].l,c[i].r))
			rv[++top]=c[i];
		else c[now++]=c[i];
	MID=now-1;
	for(int i=1;i<=top;++i)
		c[now++]=rv[i];
	solve(l,mid,L,MID);
	solve(mid+1,r,MID+1,R);
}

signed main()
{
	freopen("function.in","r",stdin);
	freopen("function.out","w",stdout);
	n=read();q=read();
	for(int i=1;i<=n;++i)
	{
		a[i]=read();
		hv[a[i]].push_back(i);
	}
	lim=n+1;
	for(int i=1;i<n;++i)
		sg.insert(i);
	sg.insert(-INF-1);
	sg.insert(INF);
	vector<Qus> st;
	for(int i=1;i<=q;++i)
	{
		int l=read(),r=read();
		if(l==r) Ans[i]=a[l];
		else c[++m]=(Qus){l,r,i};
	}
	solve(1,n,1,m);
	for(int i=1;i<=q;++i)
		write(Ans[i]),puts("");
	return 0;
}

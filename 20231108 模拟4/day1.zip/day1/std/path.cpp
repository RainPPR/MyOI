#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define lowbit(x) (x&(-x))
#define pr pair<int,int>
#define let const auto
const int N=1e6+15,M=1e6+15;
const int MAXSIZE = 1 << 20;
char buf[MAXSIZE], *p1, *p2;
#define gc()                                                               \
  (p1 == p2 && (p2 = (p1 = buf) + fread(buf, 1, MAXSIZE, stdin), p1 == p2) \
       ? EOF                                                               \
       : *p1++)

inline int read() {
  int x = 0, f = 1;
  char c = gc();
  while (!isdigit(c)) {
    if (c == '-') f = -1;
    c = gc();
  }
  while (isdigit(c)) x = x * 10 + (c ^ 48), c = gc();
  return x * f;
}

int n,m,k,ans,pos[N],xu[N];
vector <int> g[N];
namespace Tree{
	int fa[N],gson[N],siz[N],top[N],de[N],in[N],out[N],cnt;
	vector <int> chain[N];
	void dfs(int u){
		siz[u]=1;
		for(let v:g[u]) if(v!=fa[u]){
			de[v]=de[u]+1,fa[v]=u,dfs(v);
			siz[u]+=siz[v];
			if(siz[v]>siz[gson[u]]) gson[u]=v;
		}
	}
	void dfs2(int u,int tp){
		top[u]=tp; in[u]=out[u]=++cnt; pos[cnt]=u;
		chain[tp].emplace_back(u);
		if(!gson[u]) return;
		dfs2(gson[u],tp);
		for(let v:g[u]) if(v!=fa[u]&&v!=gson[u]) dfs2(v,v);
		out[u]=cnt;
	}
	int LCA(int u,int v){
		while(top[u]!=top[v])
			de[top[u]]>de[top[v]]?u=fa[top[u]]:v=fa[top[v]];
		return de[u]<de[v]?u:v;
	}
	int kfa(int u,int kth){
		while(1){
			int dis=de[u]-de[top[u]];
			if(kth<=dis) return chain[top[u]][dis-kth];
			u=fa[top[u]]; kth-=dis+1;
		}
		return 114514;
	}
	int find_las(int u,int v){return kfa(u,de[u]-de[v]-1);}
}

namespace Case1{
	const int M=N*20;
	struct node{int sum,L,R;}s[M];
	int tot,rt[N];
#define ls(k) s[k].L
#define rs(k) s[k].R
#define sum(k) s[k].sum
	void insert(int &rt,int u,int l=1,int r=n){
		if(!rt) rt=++tot;
		sum(rt)++;
		if(l==r) return;
		let mid=(l+r)>>1;
		u<=mid?insert(ls(rt),u,l,mid):insert(rs(rt),u,mid+1,r);
	}
	int merge(int k1,int k2,int l=1,int r=n){
		if(!k1||!k2) return k1|k2;
		sum(k1)+=sum(k2);
		if(l==r) return k1;
		let mid=(l+r)>>1;
		ls(k1)=merge(ls(k1),ls(k2),l,mid);
		rs(k1)=merge(rs(k1),rs(k2),mid+1,r); 
		return k1;
	}
	int binary(int rt){
		int l=1,r=n,kth=k;
		while(l<r){
			let mid=(l+r)>>1;
			if(ls(rt)&&sum(ls(rt))>=kth) r=mid,rt=ls(rt);
			else kth-=sum(ls(rt)),l=mid+1,rt=rs(rt);
		}
		return l;
	}
	void work(int rt,int dep){ 
		if(sum(rt)<k) return;
		ans=max(ans,dep-binary(rt));
	}
	vector <int> anc[N];
	void add(int u,int v){if(u!=v) anc[u].emplace_back(Tree::de[v]+1);}
	void solve(){
		for(int j=n; j; j--){
			int i=pos[j];
			for(let v:g[i]) if(v!=Tree::fa[i])
				rt[i]=merge(rt[i],rt[v]);
			for(let d:anc[i]) insert(rt[i],d);
			work(rt[i],Tree::de[i]+1);
		}
	}
}

namespace Case2{
	vector <pr> ver[N];
	void Add(int u,int v,int l){
		if(u==l||v==l) return;
		int s=Tree::find_las(u,l),t=Tree::find_las(v,l);
		if(Tree::gson[l]==s) ver[l].emplace_back(v,u);
		else if(Tree::gson[l]==t) ver[l].emplace_back(u,v);
		else if(make_pair(Tree::siz[s],s)<make_pair(Tree::siz[t],t)) ver[l].emplace_back(u,v);
		else ver[l].emplace_back(v,u);
	}
	
	int c[N];
	void add(int x,int y){while(x<=n) c[x]+=y,x+=lowbit(x);}
	int Qry(int x){int res=0; while(x) res+=c[x],x-=lowbit(x); return res;}
	int query(int l,int r){return Qry(r)-Qry(l-1);}
	
	
	vector <int> per[N],cur;
	int siz[N],gson[N];
	void calcsiz(int u){
		siz[u]=per[u].size();
		gson[u]=0;
		for(let v:g[u]) if(v!=Tree::fa[u]){
			calcsiz(v); siz[u]+=siz[v];
			if(siz[v]>siz[gson[u]]) gson[u]=v;
		}
	}
	void addpoint(int u,int v,const int rt,int Setsize){
		add(Tree::in[v],1);
		if(Setsize<k) return; 
		int dis=Tree::de[u]+Tree::de[v]-2*Tree::de[rt];
		while(1){
			if(dis<=ans) return;
			int kth=dis-ans-1;
			int kfa=Tree::kfa(v,kth);
			if(query(Tree::in[kfa],Tree::out[kfa])>=k) ans++;
			else break;
		}
	}
	void dfs(int u,vector <int>& s,const int rt){
		if(!gson[u]){
			for(let v:per[u]) addpoint(u,v,rt,s.size()+1),s.emplace_back(v);
			return;
		}
		vector <int> t,p;
		for(let v:g[u]) if(v!=gson[u]&&v!=Tree::fa[u]){
			dfs(v,p,rt);
			for(let v:p)
				add(Tree::in[v],-1),t.emplace_back(v);
			p.clear();
		}
		dfs(gson[u],s,rt);
		for(let v:t) addpoint(u,v,rt,s.size()+1),s.emplace_back(v);
		for(let v:per[u]) addpoint(u,v,rt,s.size()+1),s.emplace_back(v);
	}
	void work(int s){
		if((int)ver[s].size()<k) return;
		for(auto &[fir,sec]: ver[s]){
			per[fir].emplace_back(sec);
			cur.emplace_back(fir);
		}
		for(let v:g[s]) if(v!=Tree::fa[s]&&v!=Tree::gson[s]){
			vector <int> Set;
			calcsiz(v);
			dfs(v,Set,s);
			for(let v:Set) add(Tree::in[v],-1);
		}
		for(let v:cur) per[v].clear();
		cur.clear();
	}
	void solve(){
		for(int i=1; i<=n; i++) work(i);
	}
}
int u[N],v[N],l[N],tim[N],tim2[N];
int main(){
//	freopen("yesfull20.in","r",stdin);
//	freopen("yesfull20.ans","w",stdout);
	n=read(),m=read(),k=read();
	for(int i=1,u,v; i<n; i++)
		u=read(),v=read(),g[u].emplace_back(v),g[v].emplace_back(u);
	Tree::dfs(1); Tree::dfs2(1,1);
	for(int i=1; i<=m; i++){
		u[i]=read(),v[i]=read(),l[i]=Tree::LCA(u[i],v[i]);
		tim[u[i]]++,tim[v[i]]++;
		tim2[l[i]]++;
	}
	for(int i=1; i<=n; i++) Case1::anc[i].reserve(tim[i]),Case2::per[i].reserve(tim[i]),Case2::ver[i].reserve(tim2[i]);
	for(int i=1; i<=m; i++){
		Case1::add(u[i],l[i]),Case1::add(v[i],l[i]);
		Case2::Add(u[i],v[i],l[i]);
	}
	Case1::solve();
	Case2::solve();
	printf("%d\n",ans);
	return 0;
}




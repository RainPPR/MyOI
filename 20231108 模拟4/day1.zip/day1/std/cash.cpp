#include<bits/stdc++.h>
using namespace std;
const int N=10000005;
typedef long long ll;
int n,k,q[N],st,ed;ll dp[N];
int X(int i){return i;}
ll Y(int i){return (i>=(k+1)?dp[i-1-k]:0)-1ll*i*(i-1);}
int main()
{
//	freopen("cash10.in","r",stdin);	
//	freopen("cash10.out","w",stdout);
	scanf("%d%d",&n,&k);dp[0]=0;q[st=ed=1]=0;
	for(int i=1;i<=n;++i)
	{
		while(st<ed&&(__int128)(Y(i)-Y(q[ed]))*(X(q[ed])-X(q[ed-1]))>(__int128)(Y(q[ed])-Y(q[ed-1]))*(X(i)-X(q[ed])))--ed;
		q[++ed]=i;while(st<ed&&Y(q[st])-Y(q[st+1])<-1ll*i*(X(q[st])-X(q[st+1])))++st;
		dp[i]=(q[st]>=(k+1)?dp[q[st]-1-k]:0)+1ll*q[st]*(i-q[st]+1);
	}
	printf("%lld\n",dp[n]);
	return 0;
}
/*
114514 1919
*/


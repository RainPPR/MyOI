#include<bits/stdc++.h>
using namespace std;
const int N=1000005;
struct edge{
	int v,nxt;
}e[N*2];
int d[N],head[N],cnt,n,m,rt,a[N];
void adde(int u,int v)
{e[++cnt].v=v;++d[v];e[cnt].nxt=head[u];head[u]=cnt;} 
void dfs(int u,int fa,int val)
{
	int nw=0,tmp=0;
	for(int i=head[u];i;i=e[i].nxt)
	{
		int v=e[i].v;if(v==fa)continue;
		dfs(v,u,nw);tmp^=nw;++nw;
	}
	a[u]=val^tmp;
}
int main()
{
	freopen("xor10.in","r",stdin);
	freopen("xor10.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1,u,v;i<n;++i)
	{
		scanf("%d%d",&u,&v);
		adde(u,v);adde(v,u);
	}
	for(int i=1;i<=n;++i)if(d[rt]<d[i])rt=i;int hb=0;
	for(int i=20;i>=0;--i)if((n-2)&(1<<i)){hb=i;break;}
	dfs(rt,0,1<<hb);a[rt]=min(a[rt],n-2); 
	for(int i=1;i<=n;++i)printf("%d ",a[i]); 
	return 0;
}
/*
5 3
1 2
2 3
2 4
4 5
*/

#include <bits/stdc++.h>
using namespace std;
const int N=16;
typedef long long ll;
int dis[N][N],n,t[N],a[N][N],ok[N],pw[N];
ll ans,dp[15000005];
int main()
{
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
		for(int j=1;j<=n;++j)
			scanf("%d",&a[i][j]),dis[i][j]=a[i][j];
	for(int k=1;k<=n;++k)
		for(int i=1;i<=n;++i)
			for(int j=1;j<=n;++j)
				dis[i][j]=min(dis[i][j],dis[i][k]+dis[k][j]);
	for(int i=1;i<=n;++i)
		for(int j=1;j<=n;++j)
			if(dis[1][i]+a[i][j]==dis[1][j])ok[j]|=(1<<(i-1));
	pw[0]=1;for(int i=1;i<=n;++i)pw[i]=pw[i-1]*3;
	dp[0]=1;ans=0;
	for(int s=0;s<pw[n];++s)if(dp[s])
	{
		int tmp=s,nd=0;
		for(int i=0;i<n;++i)
		{
			t[i]=tmp%3;tmp/=3;
			if(t[i]==2)nd|=(1<<i);
		}
		bool flag=1;
		for(int i=0;i<n;++i)if(!t[i])
		{
			flag=0;
			if((ok[i+1]&nd)||!i)dp[s+pw[i]*2]+=dp[s];
			else dp[s+pw[i]]+=dp[s];
		}
		if(!flag)continue;flag=1;
		for(int i=1;i<n;++i)flag&=((ok[i+1]&nd)>0);
		if(flag)ans+=dp[s];
	}
	printf("%lld",ans);
	return 0;
}
/*
4
0 810 2 3 
2 0 514 3 
2 1919 0 1 
3 114 1 0 
*/
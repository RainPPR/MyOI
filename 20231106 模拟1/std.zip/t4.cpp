#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 5e5+5;
int n,m;
int p[N];

int par[N];
int hed[N],to[N<<1],nxt[N<<1],cnt;
inline void adde(int u,int v){
	++cnt;to[cnt]=v,nxt[cnt]=hed[u];hed[u]=cnt;
}


typedef pair<int,int> pi;
#define mid ((l+r)>>1)
int tg[N<<2];
pair<int,int> dat[N<<2];
// inline void pushtag(int x,int p){dat[x].first+=p;tg[x]+=p;}
inline void pushdown(int x,int l,int r){
	if(tg[x]){
		if(l^r){
			dat[x<<1].first+=tg[x],tg[x<<1]+=tg[x];
			dat[x<<1|1].first+=tg[x],tg[x<<1|1]+=tg[x];
		}//pushtag(x<<1,tg[x]),pushtag(x<<1|1,tg[x]);
		tg[x]=0;
	}
}
pi operator + (const pi a,const pi b){
	if(a.first==b.first)return pi(a.first,a.second+b.second);
	return min(a,b);
}

inline pi query(int x,int l,int r,int ql,int qr){
	pushdown(x,l,r);
	if(ql<=l&&qr>=r){
		return dat[x];
	}
	if(ql>mid)return query(x<<1|1,mid+1,r,ql,qr);
	if(qr<=mid)return query(x<<1,l,mid,ql,qr);
	return query(x<<1,l,mid,ql,qr)+query(x<<1|1,mid+1,r,ql,qr);
}
inline void add(int x,int l,int r,int ql,int qr,int p){
	// if(x==1)cout << ql << " " << qr << " " << p << endl;
	pushdown(x,l,r);
	if(ql<=l&&qr>=r){dat[x].first+=p,tg[x]+=p;return ;}
	if(ql<=mid)add(x<<1,l,mid,ql,qr,p);
	if(qr>mid)add(x<<1|1,mid+1,r,ql,qr,p);
	dat[x]=dat[x<<1]+dat[x<<1|1];
}
inline void build(int x,int l,int r){
	if(l==r){dat[x]=pi(l,1);return ;}
	build(x<<1,l,mid);build(x<<1|1,mid+1,r);
	dat[x] = dat[x<<1]+dat[x<<1|1];
}
#undef mid

set<int> Nxt[N];
inline void dfs(int x,int pre){
	par[x] = pre;
	for(int i=hed[x];i;i=nxt[i]){
		int v=to[i];if(v==pre)continue;
		dfs(v,x);
	}
}
set<pi> spe;

void remake(int x,int rem){
	// cout << "remake" << x << " " << rem << endl;
	// cout << Nxt[x].size() << endl;
	set<int>::iterator it = Nxt[x].begin();
	if(it!=Nxt[x].end()){
		add(1,1,n,max(*it, p[x]),n,-rem);
		++it;
		if(it!=Nxt[x].end()){
			int w=*it;
			// cout << rem << " >>> " << x << endl;
			if(rem==-1){
				spe.erase(pi(max(w,p[x]),x));
			}else {
				spe.insert(pi(max(w,p[x]),x));
			}
		}
	}
}

void calcans(){
	int ret=0;
	pi ans=query(1,1,n,1,n);
	ret+=ans.first==1?ans.second:0;
	// cout << ans.first << " " << ans.second << endl;
	if(spe.begin()==spe.end()){
		printf("%d\n",ret);
		return ;
	}
	set<pi>::iterator nxt=spe.begin(),it=spe.begin();
	// cout << it->second << " " << it->first << endl;
	int Lft=it->first;
	int Rgt=n;
	if(par[it->second])Rgt=p[par[it->second]]-1;
	++nxt;
	// cout << nxt->first << " " << nxt->second << endl;
	if(nxt!=spe.end()){
		Rgt=min(Rgt,nxt->first-1);
	}
	// cout << Lft << " " << Rgt << endl;
	if(Lft>Rgt){
		printf("%d\n",ret);
		return ;
	}
	ans=query(1,1,n,Lft,Rgt);
	ret+=ans.first==2?ans.second:0;
	printf("%d\n",ret);
}

int main()
{
	cin >> n;
	build(1,1,n);
	for(int i=1;i<=n;i++){
		scanf("%d",&p[i]);
		++p[i];
	}
	for(int i=1;i<n;i++){
		int u,v;scanf("%d%d",&u,&v);
		adde(u,v);adde(v,u);
	}
	dfs(1,0);
	for(int i=1;i<=n;i++)if(par[i]){
		Nxt[par[i]].insert(p[i]);
	}
	for(int i=1;i<=n;i++)remake(i,1);
	// calcans();
	cin >> m;
	while(m--){
		int u,v;scanf("%d%d",&u,&v);
		remake(u,-1),remake(v,-1);
		if(par[u]&&par[u]!=v)remake(par[u],-1);
		if(par[v]&&par[v]!=par[u]&&par[v]!=u)remake(par[v],-1);
		if(par[u])Nxt[par[u]].erase(p[u]);
		if(par[v])Nxt[par[v]].erase(p[v]);
		if(par[u])Nxt[par[u]].insert(p[v]);
		if(par[v])Nxt[par[v]].insert(p[u]);
		// cout << (*Nxt[1].begin()) << endl;
		swap(p[u],p[v]);
		remake(u,1),remake(v,1);
		if(par[u]&&par[u]!=v)remake(par[u],1);
		if(par[v]&&par[v]!=par[u]&&par[v]!=u)remake(par[v],1);
		calcans();
	}
}

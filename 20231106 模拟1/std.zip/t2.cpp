#include<algorithm>
#include<cstdio>
#include<iostream>
#include<queue>
#include<vector>
using namespace std;
const int N=500005;
priority_queue<int,vector<int>,greater<int> > q1;
//此处q1为“最多可以获得的”所使用的堆。 
priority_queue<int,vector<int>,less<int> > q2;
//此处q2为“最少可以失去的”所使用的堆。
queue<int> a;
int head[N];
struct Edge{
	int to,nxt;
} e[N];
int sum;
void add(int x,int y){
	e[++sum].nxt=head[x];
	e[sum].to=y;
	head[x]=sum;
}//典型链式前向星存图。 
int n,m;
int ru[N],ru2[N];
void best_(){//最好状态下可以获得最多的筹码 
	int x=0,ans=0;
    while(!q1.empty()){
    	int u=q1.top();
    	q1.pop();
    	if(u>x){
    		ans++;
		}//由于本函数计算的是运气好的情况，只要大于目前max就答案加一 
		x=max(x,u);
		for(int i=head[u];i;i=e[i].nxt){
			int v=e[i].to;
			ru[v]--;
			if(ru[v]==0) q1.push(v);
		}//遍历这个点 
	}
	cout<<ans<<endl;
}
void worst_(){//最坏状态下可以失去最少的筹码 
	int x=0,ans=0;
	while(!q2.empty()){
		int u=q2.top();
		if(u>x){
			ans++;
		}//由于本函数计算的是运气坏的情况，只要大于目前max就答案加一
		while(!q2.empty()){
			a.push(q2.top());
			q2.pop();
		}
		while(!a.empty()){
			int b=a.front();
			a.pop();
			x=max(x,b);
			for(int j=head[b];j;j=e[j].nxt){
				int v=e[j].to;
				ru2[v]--;
				if(ru2[v]==0){
					if(v>x) q2.push(v);
					else a.push(v);
				}
			}
		}
	}
	cout<<ans;
}
int main(){

	cin>>n>>m;
	for(int i=1;i<=m;i++){
		int u,v;
		cin>>u>>v;
		add(u,v);
		ru[v]++;
		ru2[v]++;
	}//输入并存图
	for(int i=1;i<=n;i++){
		if(ru[i]==0){
			q1.push(i);
			q2.push(i);
		}
	}//插入
	best_();
	worst_();
}

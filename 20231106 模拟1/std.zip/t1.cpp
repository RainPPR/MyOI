#include "bits/stdc++.h"
using namespace std;
 
using LL = long long;
 
int main() {
  int n, d, e; 
  cin >> n >> d >> e;
  e *= 5;
  int ans = n;
  for (int i = 0; i <= n; i += e) {
    ans = min(ans, (n - i) % d);
  }
  cout << ans << endl;
  return 0;
}

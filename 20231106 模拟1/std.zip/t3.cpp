#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int,int> pi;
const int N = 5e5+5;
int a[N], n, Rev;

const int inf = 0x3f3f3f3f;
#define mid ((l+r)>>1)
pi t[N<<2];
inline void build(int x,int l,int r){
	t[x] = pi(0, 0);
	if(l==r){return ;}
	build(x<<1,l,mid), build(x<<1|1,mid+1,r);
}

inline void modify(int x,int l,int r,int p, pi dat){
	if(l==r){t[x] = max(t[x], dat);return ;}
	if(p<=mid) modify(x<<1, l, mid, p, dat);
	else modify(x<<1|1, mid+1, r, p, dat);
	t[x] = max(t[x<<1], t[x<<1|1]);
}

inline pi query(int x,int l,int r,int ql,int qr){
	if(ql<=l&&qr>=r)return t[x];
	if(ql>mid)return query(x<<1|1,mid+1,r,ql,qr);
	if(qr<=mid)return query(x<<1,l,mid,ql,qr);
	return max(query(x<<1,l,mid,ql,qr) ,query(x<<1|1,mid+1,r,ql,qr));
}
#undef mid
#define lowbit(x) ((x) & (-x))
struct fenwick{
	pi t[N];
	inline void ins(int x,pi dat){
		for(;x<=n;x+=lowbit(x)){t[x] = max(t[x], dat);}
	}
	inline pi query(int x){
		pi ans = pi(0,0);
		for(;x;x-=lowbit(x))ans = max(ans, t[x]);
		return ans;
	}
	inline void clear(){for(int i=1;i<=n;i++)t[i] = pi(0,0);}
}bit;

pi lispre[N], lisnxt[N];
pi ldspre[N], ldsnxt[N];
vector<int> op[N];
int pos[N];

inline void Getans(int x,int y,int r){
	vector<int> ans1, ans2;
	for(int i = x; i; i = lispre[i].second) ans1.push_back(i);
	for(int i = y; i; i = ldspre[i].second) ans2.push_back(i);
	reverse(ans1.begin(), ans1.end());
	reverse(ans2.begin(), ans2.end());
	for(int i = lisnxt[x].second;i ;i = lisnxt[i].second)ans1.push_back(i);
	for(int i = ldsnxt[y].second;i ;i = ldsnxt[i].second)ans2.push_back(i);
	if(!r){
		cout << ans1.size() << endl;
		for(size_t i=0;i<ans1.size();i++)printf("%d ",ans1[i]);puts("");
		cout << ans2.size() << endl;
		for(size_t i=0;i<ans2.size();i++)printf("%d ",ans2[i]);puts("");
	}else{
		reverse(ans1.begin(), ans1.end());
		reverse(ans2.begin(), ans2.end());
		cout << ans2.size() << endl;
		for(size_t i=0;i<ans2.size();i++)printf("%d ",n+1-ans2[i]);puts("");
		cout << ans1.size() << endl;
		for(size_t i=0;i<ans1.size();i++)printf("%d ",n+1-ans1[i]);puts("");
	}
	exit(0);
}

inline void solve(){
	// for(int i=1;i<=n;i++)cout << a[i] << " ";
	// puts("");
	int Len1=0, Len2=0;
	bit.clear();
	for(int i=1;i<=n;i++){
		lispre[i] = bit.query(a[i]);
		lispre[i].first ++ ;
		Len1 = max(Len1, lispre[i].first);
		bit.ins(a[i], pi(lispre[i].first, i));
	}
	bit.clear();
	for(int i=n;i;i--){
		lisnxt[i] = bit.query(n-a[i]+1);
		lisnxt[i].first ++;
		if(lisnxt[i].second)lisnxt[i].second = n + 1 - lisnxt[i].second;
		bit.ins(n-a[i]+1, pi(lisnxt[i].first, n+1-i));
	}
	bit.clear();
	for(int i=1;i<=n;i++){
		ldspre[i] = bit.query(n-a[i]+1);
		ldspre[i].first ++ ;
		Len2 = max(Len2, ldspre[i].first);
		bit.ins(n-a[i]+1, pi(ldspre[i].first, i));
	}
	bit.clear();
	for(int i=n;i;i--){
		ldsnxt[i] = bit.query(a[i]);
		ldsnxt[i].first ++;
		// cout << i << ":" << ldsnxt[i].second << endl;
		bit.ins(a[i], pi(ldsnxt[i].first, i));
	}
	for(int i=1;i<=n;++i)op[i].clear();
	for(int i=1;i<=n;i++){
		if(lisnxt[i].second && lisnxt[i].first + lispre[i].first - 1 == Len1){
			op[a[i]].push_back(i);
		}
		pos[a[i]] = i;
	}
	build(1,1,n);
	for(int i=1;i<=n;i++){
		int x = pos[i] ;
		if(ldsnxt[x].second && ldspre[x].first + ldsnxt[x].first - 1 == Len2){
			int y = ldsnxt[x].second;
			// cout << x << ": " << y << endl;
			pi ret = query(1,1,n,x,y-1);
			// cout << ret.second << endl;
			if(ret.first > i)Getans(ret.second, x, Rev);
		}
		for(size_t j=0;j<op[i].size();j++){
			int id = op[i][j];
			modify(1,1,n,id,pi(a[lisnxt[id].second],id));
		}
	}
}

int main()
{
	cin >> n;
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	// a[0] = 0, a[n+1] = n + 1;
	solve();
	reverse(a+1, a+n+1);Rev=1;
	// for(int i=1;i<=n;++i)a[i] = n+1-a[i];
	solve();
//	cerr << "IMPOSSIBLE" << endl;
	puts("-1");
	return 1;
	return 0;
}

#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<ctime>
#include<vector>
#include<queue>
#include<algorithm>
#include<string>
#include<sstream>
#include<cctype>
#include<cmath>
#include<iomanip>
#include<map>
#include<stack>
#include<set>
#include<functional>
#define in(x) x=read()
#define qr read()
//#define int ll
#define mp make_pair
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
namespace fastIO
{
    #define BUF_SIZE 100000
    bool IOerror=0;
    inline char nc()
	{
        static char buf[BUF_SIZE],*p1=buf+BUF_SIZE,*pend=buf+BUF_SIZE;
        if (p1==pend){
            p1=buf; pend=buf+fread(buf,1,BUF_SIZE,stdin);
            if (pend==p1){IOerror=1;return -1;}
        }
        return *p1++;
    }
    inline bool blank(char ch){return ch==' '||ch=='\n'||ch=='\r'||ch=='\t';}
    inline ll read()
	{
        bool sign=0; char ch=nc();ll x=0;
        for (;blank(ch);ch=nc());
        if (IOerror)return 0;
        if (ch=='-')sign=1,ch=nc();
        for (;ch>='0'&&ch<='9';ch=nc())x=x*10+ch-'0';
        if (sign)x=-x;
        return x;
    }
    #undef BUF_SIZE
};
using namespace fastIO;
int vis[1000010],a[1000010];
set<int>s,t;
vector<int>ans;
signed main()
{
	//freopen(".in","r",stdin);
	//freopen(".out","w",stdout);
	int T=qr;
	while(T--)
	{
		int n=qr;
		for(int i=0;i<=n;i++)vis[i]=0;
		for(int i=1;i<=n;i++)in(a[i]),vis[a[i]]++;
		s.clear();ans.clear();
		for(int i=0;i<n;i++)if(!vis[i])s.insert(i);
		for(int i=1;i<=n;i++)
		{
			if(a[i]!=i-1)t.insert(i);
		}
		while(!t.empty())
		{
			// cout<<"t:";
			// for(auto i:t)cout<<i<<' ';cout<<'\n';
			// cout<<"s:";
			// for(auto i:s)cout<<i<<' ';cout<<'\n';
			// for(int i=0;i<n;i++)cout<<vis[i]<<' ';cout<<'\n';
			if(!s.empty())
			{
				int now=*s.begin();
				vis[a[now+1]]--;
				if(!vis[a[now+1]]&&a[now+1]<n)s.insert(a[now+1]);
				ans.push_back(now+1);
				t.erase(now+1);
				vis[now]=1;
				s.erase(now);
			}
			else
			{
				int now=*t.begin();
				ans.push_back(now);
				vis[a[now]]--;
				if(!vis[a[now]]&&a[now]<n)s.insert(a[now]);
				a[now]=n+1;
			}
		}
		cout<<ans.size()<<'\n';
		for(auto i:ans)cout<<i<<' ';cout<<'\n';
	}
	return 0;
}
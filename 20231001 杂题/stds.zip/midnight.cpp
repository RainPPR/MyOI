#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<ctime>
#include<vector>
#include<queue>
#include<algorithm>
#include<string>
#include<sstream>
#include<cctype>
#include<cmath>
#include<iomanip>
#include<map>
#include<stack>
#include<set>
#include<functional>
#include<unordered_map>
#define in(x) x=read()
#define qr read()
//#define int ll
#define mp make_pair
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
namespace fastIO
{
    #define BUF_SIZE 100000
    bool IOerror=0;
    inline char nc()
	{
        static char buf[BUF_SIZE],*p1=buf+BUF_SIZE,*pend=buf+BUF_SIZE;
        if (p1==pend){
            p1=buf; pend=buf+fread(buf,1,BUF_SIZE,stdin);
            if (pend==p1){IOerror=1;return -1;}
        }
        return *p1++;
    }
    inline bool blank(char ch){return ch==' '||ch=='\n'||ch=='\r'||ch=='\t';}
    inline ll read()
	{
        bool sign=0; char ch=nc();ll x=0;
        for (;blank(ch);ch=nc());
        if (IOerror)return 0;
        if (ch=='-')sign=1,ch=nc();
        for (;ch>='0'&&ch<='9';ch=nc())x=x*10+ch-'0';
        if (sign)x=-x;
        return x;
    }
    #undef BUF_SIZE
};
using namespace fastIO;
char x[1000100],y[1000010];
int f[2010][2010],n;
int c[4010][2010];
void add1(int i,int j,int x)
{
	for(;j<=n+1;j+=(j&(-j)))c[i][j]+=x;
}
void add(int i,int l,int r,int x)
{
	add1(i,l,x);
	add1(i,r+1,-x);
}
int query(int i,int j)
{
	if(!j)return 0;
	int ans=0;
	for(;j;j-=(j&(-j)))ans+=c[i][j];
	return ans;
}
signed main()
{
	freopen("midnight.in","r",stdin);
	freopen("midnight.out","w",stdout);
	n=qr;
	for(int i=1;i<=n;i++)x[i]=x[i+n]=nc();nc();
	for(int i=1;i<=n;i++)y[i]=nc();
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			f[i][j]=max(f[i-1][j],f[i][j-1]);
			if(x[i]==y[j])f[i][j]=max(f[i][j],f[i-1][j-1]+1);
			add(i,j,j,f[i][j]);
		}
	}
	int ans=f[n][n];
	for(int i=1;i<=n;i++)
	{
		int pos=1;
		for(int j=1;j<=n+1;j++)c[i][j]=0;
		for(int j=1;j<n;j++)
		{
			while(pos<=n)
			{
				int f1=query(i+j,pos-1),f2=query(i+j-1,pos),f3=query(i+j-1,pos-1),f4=query(i+j,pos);
				int now=max(f1,f2);
				if(x[i+j]==y[pos])now=max(now,f3+1);
				if(now==f4)pos++;
				else break;
			}
			add(i+j,pos,n,-1);
		}
		for(int j=1;j<=n;j++)
		{
			int f1=query(n+i,j-1),f2=query(n+i-1,j),f3=query(n+i-1,j-1);
			int now=max(f1,f2);
			if(x[n+i]==y[j])now=max(now,f3+1);
			add(i+n,j,j,now);
		}
		ans=max(ans,query(i+n,n));
	}
	cout<<ans;
	return 0;
}
//��ʹ����ԭ��������Ԥ�ڣ��Ի���һ��ǫ��������Բ��������� 
//�������̫��񣬴��Ʒ�С���� 

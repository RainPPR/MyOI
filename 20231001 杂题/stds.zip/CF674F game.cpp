#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<ctime>
#include<vector>
#include<queue>
#include<algorithm>
#include<string>
#include<sstream>
#include<cctype>
#include<cmath>
#include<iomanip>
#include<map>
#include<stack>
#include<set>
#include<functional>
#include<cassert>
#include<unordered_map>
#include<unordered_set>
#define in(x) x=read()
#define qr read()
#define int ll
#define mp make_pair
#define pii pair<int,int>
#define fi first
#define se second
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
namespace fastIO
{
    #define BUF_SIZE 100000
    bool IOerror=0;
    inline char nc()
	{
        static char buf[BUF_SIZE],*p1=buf+BUF_SIZE,*pend=buf+BUF_SIZE;
        if (p1==pend){
            p1=buf; pend=buf+fread(buf,1,BUF_SIZE,stdin);
            if (pend==p1){IOerror=1;return -1;}
        }
        return *p1++;
    }
    inline bool blank(char ch){return ch==' '||ch=='\n'||ch=='\r'||ch=='\t';}
    inline ll read()
	{
        bool sign=0; char ch=nc();ll x=0;
        for (;blank(ch);ch=nc());
        if (IOerror)return 0;
        if (ch=='-')sign=1,ch=nc();
        for (;ch>='0'&&ch<='9';ch=nc())x=x*10+ch-'0';
        if (sign)x=-x;
        return x;
    }
    #undef BUF_SIZE
};
using namespace fastIO;
#define mod 1000000007
int l=0,n=1,a[1000010],s[1000010],f[2][2][2][1000010];
int c2(int x)
{
	if(x<=0)return 0;
	return (x*(x-1)/2)%mod;
}
signed main()
{
	//freopen(".in","r",stdin);
	//freopen(".out","w",stdout);
	int p=qr,c=qr;
	char ch=nc();
	for(;isdigit(ch);ch=nc())s[++l]=ch-'0';
	for(int i=1;i<=l;i++)
	{
		for(int j=1;j<=n;j++)a[j]*=10;
		a[1]+=s[i];
		for(int j=1;j<=n;j++)
		{
			if(a[j]>=p)a[j+1]+=a[j]/p,a[j]%=p;
		}
		while(a[n+1])
		{
			n++;
			if(a[n]>=p)a[n+1]+=a[n]/p,a[n]%=p;
		}
	}
	reverse(a+1,a+1+n);
	f[n&1^1][0][0][0]=f[n&1^1][0][1][0]=1;
	for(int i=n;i>=1;i--)
	{
		for(int j=0;j<=n;j++)
		{
			for(int k=0;k<2;k++)
			{
				for(int l=0;l<2;l++)
				{
					f[i&1][k][l][j]=0;
				}
			}
		}
		for(int j=0;j<=n-i;j++)
		{
			f[i&1][1][1][j+1]+=f[i&1^1][0][1][j]*(p-1-a[i]);
			f[i&1][1][1][j+1]+=f[i&1^1][1][1][j]*(p-a[i]);
			f[i&1][0][1][j]+=f[i&1^1][0][1][j]*(a[i]+1);
			f[i&1][0][1][j]+=f[i&1^1][1][1][j]*a[i];
			f[i&1][1][1][j+1]+=f[i&1^1][0][0][j]*(c2(a[i]+1)+a[i]*(p-1-a[i])%mod);
			f[i&1][1][1][j+1]+=f[i&1^1][1][0][j]*(c2(a[i]+1)+a[i]*(p-a[i])%mod);
			f[i&1][0][1][j]+=f[i&1^1][0][0][j]*c2(a[i]+1);
			f[i&1][0][1][j]+=f[i&1^1][1][0][j]*c2(a[i]);
			f[i&1][0][1][j]%=mod,f[i&1][1][1][j+1]%=mod;
			f[i&1][1][0][j+1]+=f[i&1^1][0][0][j]*c2(p);
			f[i&1][1][0][j+1]+=f[i&1^1][1][0][j]*c2(p+1);
			f[i&1][0][0][j]+=f[i&1^1][0][0][j]*c2(p+1);
			f[i&1][0][0][j]+=f[i&1^1][1][0][j]*c2(p);
			f[i&1][0][0][j]%=mod,f[i&1][1][0][j+1]%=mod;
		}
	}
	int ans=0;
	for(int i=c;i<=n;i++)
	{
		ans+=f[1][0][1][i],ans%=mod;
	}
	cout<<ans;
	return 0;
}
//....
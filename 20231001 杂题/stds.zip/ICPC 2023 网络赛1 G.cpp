#include<bits/stdc++.h>
using namespace std;
#define x first
#define y second
typedef long long ll;
const int N = 1e6 + 10, mod = 998244353;
typedef pair<int, int> PII;
ll qmi(ll a, ll b) {
	ll res = 1;
	while (b) {
		if (b & 1) res = res * a % mod;
		a = a * a % mod;
		b >>= 1;
	}
	return res;
}
PII q[N];
int f[N],p[N],dep[N];
ll sz[N];
vector<int> g[N];
void dfs(int u, int fa) {
	p[u] = fa;
	for (auto j : g[u]) {
		if (j == fa) continue;
		dep[j] = dep[u] + 1;
		dfs(j, u);
	}
}
int find(int x) {
	if (x != f[x]) f[x] = find(f[x]);
	return f[x];
}
int main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	int n;
	cin >> n;
	for (int i = 1; i <= n; ++i) {
		f[i] = i;
		sz[i] = 1;
	}
	for (int i = 1; i < n; ++i) {
		cin >> q[i].x >> q[i].y;
	}
	for (int i = 1; i < n; ++i) {
		int u, v;
		cin >> u >> v;
		g[u].push_back(v);
		g[v].push_back(u);
	}
	dfs(1, 0);
	bool flag = 1;
	ll ans = 1;
	for (int i = 1; i < n; ++i) {
		int u = find(q[i].x);
		int v = find(q[i].y);
		if (dep[u] < dep[v]) {
			swap(u, v);
		}
		if (find(p[u]) != v) {
			flag = 0;
			break;
		}
		ans = ans * sz[u] % mod * sz[v] % mod;
		f[u] = v;
		sz[v] += sz[u];
	}
	if (!flag) {
		cout << 0;
	} else {
		cout << qmi(ans, mod - 2);
	}
}
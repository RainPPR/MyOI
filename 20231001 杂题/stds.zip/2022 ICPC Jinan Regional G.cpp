#include<bits/stdc++.h>
using namespace std;
#define in(x) x=read()
#define qr read()
#define int ll
#define mp make_pair
typedef long long ll;
typedef unsigned long long ull;
namespace fastIO
{
    #define BUF_SIZE 100000
    bool IOerror=0;
    inline char nc()
    {
        static char buf[BUF_SIZE],*p1=buf+BUF_SIZE,*pend=buf+BUF_SIZE;
        if (p1==pend){
            p1=buf; pend=buf+fread(buf,1,BUF_SIZE,stdin);
            if (pend==p1){IOerror=1;return -1;}
        }
        return *p1++;
    }
    inline bool blank(char ch){return ch==' '||ch=='\n'||ch=='\r'||ch=='\t';}
    inline ll read()
    {
        bool sign=0; char ch=nc();ll x=0;
        for (;blank(ch);ch=nc());
        if (IOerror)return 0;
        if (ch=='-')sign=1,ch=nc();
        for (;ch>='0'&&ch<='9';ch=nc())x=x*10+ch-'0';
        if (sign)x=-x;
        return x;
    }
    #undef BUF_SIZE
};
using namespace fastIO;
int c1[4000010],a[4000010],c2[4000010],ans=0,n;
void pushup(int x){c1[x]=max(c1[x<<1],c1[x<<1|1]),c2[x]=min(c2[x<<1],c2[x<<1|1]);}
void build(int l,int r,int x)
{
    if(l==r)
    {
        c1[x]=c2[x]=a[l];
        return;
    }
    int mid=(l+r)/2;
    build(l,mid,x<<1);
    build(mid+1,r,x<<1|1);
    pushup(x);
}
void modify(int l,int r,int p,int v,int x)
{
    if(l==r)
    {
        c1[x]=c2[x]=v;
        return;
    }
    int mid=(l+r)/2;
    if(p<=mid)modify(l,mid,p,v,x<<1);
    else modify(mid+1,r,p,v,x<<1|1);
    pushup(x);
}
int find2(int nl,int nr,int l,int r,int v,int x)
{
    if(l>r)return -1;
    if(c2[x]>v)return -1;
    if(nl==nr)return nl;
    int mid=(nl+nr)/2,ans=-1;
    if(r>mid)ans=find2(mid+1,nr,l,r,v,x<<1|1);
    if(l<=mid&&ans==-1)ans=find2(nl,mid,l,r,v,x<<1);
    return ans;
}
int find1(int nl,int nr,int l,int r,int v,int x)
{
    if(l>r)return -1;
    if(c1[x]<v)return -1;
    if(nl==nr)return nl;
    int mid=(nl+nr)/2,ans=-1;
    if(l<=mid)ans=find1(nl,mid,l,r,v,x<<1);
    if(r>mid&&ans==-1)ans=find1(mid+1,nr,l,r,v,x<<1|1);
    return ans;
}
void doit(int x,int y)
{
    ans++;
    modify(1,n,x,a[y],1);
    modify(1,n,y,a[x],1);
    swap(a[x],a[y]);
    // cout<<x<<","<<y<<'\n';
}
void qsort(int l,int r)
{
    if(l>=r)return;
    int p=a[(l+r)/2];
    int lp=l-1,rp=r+1;
    while(1)
    {
        lp=find1(1,n,lp+1,r,p,1);
        rp=find2(1,n,l,rp-1,p,1);
        if(lp>=rp)
        {
            qsort(l,rp);
            qsort(rp+1,r);
            return;
        }
        else doit(lp,rp);
    }
}
signed main()
{
    int T=qr;
    while(T--)
    {
        n=qr;
        for(int i=1;i<=n;i++)
        {
            in(a[i]);
        }
        ans=0;
        build(1,n,1);
        qsort(1,n);
        cout<<ans<<'\n';
    }
    return 0;
}
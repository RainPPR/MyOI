#include <bits/stdc++.h>
 
#define gc() getchar()
template <typename T> inline void rd(T& x) {
	int si = 1; char c = gc(); x = 0;
	while(!isdigit(c)) si = c == '-' ? -1 : si, c = gc();
	while(isdigit(c)) x = x * 10 + c - 48, c = gc();
	x *= si;
}
template <typename T, typename... Args>
inline void rd(T& x, Args&... args) { rd(x); rd(args...); }
#define fi first
#define se second
#define mkp std::make_pair
typedef unsigned ui;
typedef long long ll;
typedef unsigned long long ull;
typedef double ff;
typedef std::pair <int, int> pii;
const int N = 1e6 + 5, MOD = 998244353, INV2 = (MOD + 1) / 2;
 
int Gcd(int a, int b) { return b ? Gcd(b, a % b) : a; }
 
int Check(int x, int y, int k) {
    if(x > y) return 0;
    return y / k - (x - 1) / k;
}
 
int main() {
#ifndef ONLINE_JUDGE
	freopen("a.in", "r", stdin);
	freopen("a.out", "w", stdout);
#endif
	int test_case_cnt = 1; rd(test_case_cnt);
	while(test_case_cnt--) {
        int n, k;
        rd(n, k);
        int x = n / k, x_cnt = k - n % k,
            y = n / k + 1, y_cnt = n % k;
        //x:第一种组的大小n/k，x_cnt:第一种组的个数 y同理
        int t = n / 2,
            l = std::max(0, (t - x * x_cnt + x) / (x + 1)),
            r = std::min(y_cnt, t / (x + 1));
        if(Check(t - r, t - l, x)) printf("Yes\n");
        else printf("No\n");
	} return 0;
}
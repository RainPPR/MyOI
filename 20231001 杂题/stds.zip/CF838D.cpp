#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<ctime>
#include<vector>
#include<queue>
#include<algorithm>
#include<string>
#include<sstream>
#include<cctype>
#include<cmath>
#include<iomanip>
#include<map>
#include<stack>
#include<set>
#include<functional>
#include<unordered_map>
#define in(x) x=read()
#define qr read()
#define int ll
#define mp make_pair
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
namespace fastIO
{
    #define BUF_SIZE 100000
    bool IOerror=0;
    inline char nc()
	{
        static char buf[BUF_SIZE],*p1=buf+BUF_SIZE,*pend=buf+BUF_SIZE;
        if (p1==pend){
            p1=buf; pend=buf+fread(buf,1,BUF_SIZE,stdin);
            if (pend==p1){IOerror=1;return -1;}
        }
        return *p1++;
    }
    inline bool blank(char ch){return ch==' '||ch=='\n'||ch=='\r'||ch=='\t';}
    inline ll read()
	{
        bool sign=0; char ch=nc();ll x=0;
        for (;blank(ch);ch=nc());
        if (IOerror)return 0;
        if (ch=='-')sign=1,ch=nc();
        for (;ch>='0'&&ch<='9';ch=nc())x=x*10+ch-'0';
        if (sign)x=-x;
        return x;
    }
    #undef BUF_SIZE
};
using namespace fastIO;
#define mod 998244353
int qpow(int n,int k)
{
	int ans=1;
	while(k)
	{
		if(k&1)ans*=n,ans%=mod;
		n*=n,n%=mod;
		k>>=1;
	}
	return ans;
}
signed main()
{
	freopen("breeze.in","r",stdin);
	freopen("breeze.out","w",stdout);
	int n=qr,m=qr;
	cout<<(n-m+1)*qpow(n+1,m-1)%mod*qpow(2,m)%mod;
	return 0;
}
//ÊÔ×ÅÈ¥ÒÅÍü×òÌì²»¶ÏÊÔ£¬ÄãÓÐ¶àÄÑ¹ýÎÒ¶¼Öª

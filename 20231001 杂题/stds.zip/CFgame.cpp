#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
using namespace std;
int n,p,q;
unsigned int val[210];
int gcd(int a,int b)
{
	return b==0?a:gcd(b,a%b);
}
int a[210],b[210];
void init()
{
	for(int k=0;k<=min(n-1,p);k++)
	{
		for(int i=1;i<=k;i++)
			b[i]=i,a[i]=n-i+1;
		for(int i=1;i<=k;i++)
			for(int j=1;j<=k;j++)
			{
				int g=gcd(a[i],b[j]);
				a[i]/=g;b[j]/=g;
			}
		val[k]=1;
		for(int i=1;i<=k;i++)
			val[k]*=(unsigned int)a[i];
	}
	return ;
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d %d %d",&n,&p,&q);
	init();
	unsigned int ans=0;
	for(int i=1;i<=q;i++)
	{
		unsigned int pw=1,sum=0;
		for(int j=0;j<=min(n-1,p);j++)
		{
			sum+=pw*val[j];
			pw*=(unsigned int)i;
		}
		ans^=sum*(unsigned int)i;
	}
	cout<<ans<<"\n";
	return 0;
}

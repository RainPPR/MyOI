#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<ctime>
#include<vector>
#include<queue>
#include<algorithm>
#include<string>
#include<sstream>
#include<cctype>
#include<cmath>
#include<iomanip>
#include<map>
#include<stack>
#include<set>
#include<functional>
#include<unordered_map>
#define in(x) x=read()
#define qr read()
#define int ll
#define mp make_pair
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
namespace fastIO
{
    #define BUF_SIZE 100000
    bool IOerror=0;
    inline char nc()
	{
        static char buf[BUF_SIZE],*p1=buf+BUF_SIZE,*pend=buf+BUF_SIZE;
        if (p1==pend){
            p1=buf; pend=buf+fread(buf,1,BUF_SIZE,stdin);
            if (pend==p1){IOerror=1;return -1;}
        }
        return *p1++;
    }
    inline bool blank(char ch){return ch==' '||ch=='\n'||ch=='\r'||ch=='\t';}
    inline ll read()
	{
        bool sign=0; char ch=nc();ll x=0;
        for (;blank(ch);ch=nc());
        if (IOerror)return 0;
        if (ch=='-')sign=1,ch=nc();
        for (;ch>='0'&&ch<='9';ch=nc())x=x*10+ch-'0';
        if (sign)x=-x;
        return x;
    }
    #undef BUF_SIZE
};
using namespace fastIO;
int t[100010],lis[100010][10],now=0,len[100010];
void dfs(int x,int a,int b,int c)
{
	if((x!=1&&a*a<x-1&&b*b<x-1&&c*c<x-1)||(x==2))
	{
		int f=1;
		for(int i=2;i<=(x-1)/2;i++)
		{
			for(int j=1;j<=x-i;j++)
			{
				for(int k=j+i;k<=x-i;k++)
				{
					int g=1;
					for(int l=0;l<i;l++)
					{
						if(t[j+l]!=t[k+l])g=0;
					}
					if(g)f=0;
				}
			}
		}
		if(f)
		{
			now++;
			len[now]=x-1;
			for(int i=1;i<x;i++)lis[now][i]=t[i];
		}
	}
	if(x>8)return;
	t[x]=1;
	dfs(x+1,a+1,b,c);
	t[x]=2;
	dfs(x+1,a,b+1,c);
	t[x]=3;
	dfs(x+1,a,b,c+1);
}
int nxt[1000010][4],pos[10],a[1000010];
signed main()
{
	freopen("city.in","r",stdin);
	freopen("city.out","w",stdout);
	dfs(1,0,0,0);
	int T=qr;
	while(T--)
	{
		int n=qr;
		for(int i=1;i<=n;i++)a[i]=nc()-'a'+1;
		for(int i=0;i<=n;i++)for(int j=1;j<=3;j++)nxt[i][j]=0;
		for(int i=1;i<=3;i++)pos[i]=0;
		for(int i=n;i>=0;i--)
		{
			for(int j=1;j<=3;j++)
			{
				nxt[i][j]=pos[j];
			}
			pos[a[i]]=i;
		}
		int res=0;
		for(int i=1;i<=now;i++)
		{
			int pos=0,pos1=1,ans=0;
			while(nxt[pos][lis[i][pos1]])
			{
				pos=nxt[pos][lis[i][pos1]];
				pos1++;
				if(pos1>len[i])pos1=1,ans++;
			}
			res=max(res,ans*ans*len[i]);
		}
		cout<<res<<'\n';
	}
	return 0;
}
//�ǲ���һ�����v�^�L��ʹ��֮�ᣬ�˟o���E�ĻÉ�

#include<bits/stdc++.h>
using namespace std;
template<typename T>inline void read(T &x) {
    x=0;T f=1,ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) {x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
    x*=f;
}
typedef long long ll;
const int N=500010;
int n,tot,x,l,root,lin[N],s[N],d[N],b[N],c[N],f[N][21];
ll ans[N];
struct gg {
    int y,next;
}a[N<<1];
vector<int>g[N];
inline void add(int x,int y) {
    a[++tot].y=y;
    a[tot].next=lin[x];
    lin[x]=tot;
} 
inline void dfs(int x) {
    g[d[x]].push_back(x);//同层节点 丢进去; 
    for(int i=lin[x];i;i=a[i].next) {
        int y=a[i].y;
        d[y]=d[x]+1;
        dfs(y);
    }
}
inline int lca(int x,int y) {
    if(d[x]>d[y]) swap(x,y);
    for(int i=20;i>=0;i--) {
        if(d[f[y][i]]>=d[x]) {
            y=f[y][i];
        }
    }
    if(x==y) return x;
    for(int i=20;i>=0;i--) {
        if(f[y][i]!=f[x][i]) {
            y=f[y][i],x=f[x][i];
        }
    }
    return f[x][0];
}
inline void slove(int i) {
    ll sum=0;
    for(int j=0;j<g[i].size();j++) {
        int x=g[i][j];
        if(!j) s[l=1]=x,b[l]=c[l]=0;
        else {
            while(1) {
                int Lca=lca(x,s[l]);
                if(b[l]<=d[Lca]) {
                    s[++l]=x,b[l]=d[Lca]+1,c[l]=j;
                    break;
                }
                sum-=1ll*(c[l]-c[l-1])*b[l];
                l--;
            }
            sum+=1ll*(c[l]-c[l-1])*b[l];
        }
        ans[x]+=sum;
    }
}
int main() {
    read(n);
    for(int i=1;i<=n;i++) {
        read(x);
        if(!x) root=i,f[i][0]=i;
        else add(x,i),f[i][0]=x;
    }
    dfs(root);
    for(int i=1;i<=20;i++) {
        for(int j=1;j<=n;j++) {
            f[j][i]=f[f[j][i-1]][i-1];
        }
    }
    for(int i=1;i<n;i++) {
        if(!g[i].size()) break;
        for(int j=0;j<g[i].size();j++) ans[g[i][j]]+=ans[f[g[i][j]][0]]+i;
        slove(i);
        reverse(g[i].begin(),g[i].end());
        slove(i);
    }
    for(int i=1;i<=n;i++) cout<<ans[i]<<' ';
    puts("");
    return 0;  
}
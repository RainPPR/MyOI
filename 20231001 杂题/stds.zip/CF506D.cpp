#include<algorithm>
#include<iostream>
#include<cstdio>
#include<cmath>
#include<map>
#define mp make_pair
#define pi pair<int,int>
using namespace std;
const int N=100005;
inline int read() {
	int sum=0,w=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if(ch=='-') w=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		sum=(sum<<3)+(sum<<1)+ch-'0';
		ch=getchar();
	}
	return sum*w;
}
int n,m,q,qx[N],qy[N],f[N],d[N],ans[N],tmp[N],siz;
struct node {
	int x,y,z;
	bool operator < (const node &a) const {
		return z<a.z;
	}
} e[N];
map<pi,int> p;
int find(int x) {//并查集
	return f[x]==x?x:f[x]=find(f[x]);
}
void merge(int x,int y) {
	x=find(x),y=find(y);
	if(x!=y) {
		if(d[x]<d[y]) swap(x,y);
		f[y]=x;
		if(d[x]==d[y]) d[x]++;
	}
}
int main() {
	n=read(),m=read();
	for(int i=1; i<=n; i++) f[i]=i;
	for(int i=1; i<=m; i++) {
		e[i].x=read(),e[i].y=read(),e[i].z=read();
		if(e[i].x>e[i].y) swap(e[i].x,e[i].y);//确保x<y 
	}
	sort(e+1,e+m+1);//按颜色排序 
	q=read();
	for(int i=1; i<=q; i++) {
		qx[i]=read(),qy[i]=read();
		if(qx[i]>qy[i]) swap(qx[i],qy[i]);//离线询问 
	}
	for(int i=1,j=1; i<=m; i=++j) {
		while(e[j].z==e[j+1].z) j++;//j的位置是最后一条该颜色的边 
		for(int k=i; k<=j; k++) merge(e[k].x,e[k].y);//做并查集 
		int tot=j-i+1; 
		if(tot<sqrt(m)) {//分块 
			siz=0;
			for(int k=i; k<=j; k++) tmp[++siz]=e[k].x,tmp[++siz]=e[k].y;//记录该颜色边所连接的点 
			sort(tmp+1,tmp+siz+1);
			siz=unique(tmp+1,tmp+siz+1)-tmp-1;//去重 
			for(int x=1; x<siz; x++)
				for(int y=x+1; y<=siz; y++)
					if(find(tmp[x])==find(tmp[y])) p[mp(tmp[x],tmp[y])]++;//在同一连通块，往点对上添加答案 
		} else for(int k=1; k<=q; k++) ans[k]+=(find(qx[k])==find(qy[k]));//直接扫询问统计答案 
		for(int k=i; k<=j; k++) f[e[k].x]=e[k].x,f[e[k].y]=e[k].y,d[e[k].x]=d[e[k].y]=0;//清空 
	}
	for(int i=1; i<=q; i++) {
		if(p.find(mp(qx[i],qy[i]))!=p.end()) ans[i]+=p[mp(qx[i],qy[i])];//统计点对对答案的贡献 
		printf("%d\n",ans[i]);
	}
	return 0;
}

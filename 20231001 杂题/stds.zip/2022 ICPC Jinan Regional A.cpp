#include <bits/stdc++.h>
 
#define gc() getchar()
template <typename T> inline void rd(T& x) {
	int si = 1; char c = gc(); x = 0;
	while(!isdigit(c)) si = c == '-' ? -1 : si, c = gc();
	while(isdigit(c)) x = x * 10 + c - 48, c = gc();
	x *= si;
}
template <typename T, typename... Args>
inline void rd(T& x, Args&... args) { rd(x); rd(args...); }
#define fi first
#define se second
#define mkp std::make_pair
typedef unsigned ui;
typedef long long ll;
typedef unsigned long long ull;
typedef double ff;
typedef std::pair <int, int> pii;
const int N = 500 + 5, MOD = 998244353, INV2 = (MOD + 1) / 2;
 
int n, m, a[N], b[N], c[N];
 
int Dist(int x, int y) {
    int ret = 2e4, j = 0;
    while(x) {
        ret = std::min(ret, std::abs(x - y) + j);
        ++j;
        x /= 2;
    }
    return ret;
}
 
int Calc(int x) {
    int ret = 0;
    for(int i = 1; i <= n - 1; ++i)
        c[i] = Dist(b[i], x);
    std::sort(c + 1, c + n);
    for(int i = 1; i <= n - m - 1; ++i)
        ret += c[i];
    return ret;
}
 
int main() {
#ifndef ONLINE_JUDGE
	freopen("a.in", "r", stdin);
	freopen("a.out", "w", stdout);
#endif
	int test_case_cnt = 1; rd(test_case_cnt);
	while(test_case_cnt--) {
        rd(n, m);
        for(int i = 1; i <= n; ++i)
            rd(a[i]);
        int ans = 1e9;
        for(int i = 1; i <= n; ++i) {
            int cur = a[i], j = 0;
            while(cur) {
                for(int k = 1; k < i; ++k) b[k] = a[k];
                for(int k = i + 1; k <= n; ++k) b[k - 1] = a[k];
                ans = std::min(ans, Calc(cur) + j);
                cur /= 2; ++j;
            }
        }
        printf("%d\n", ans);
	} return 0;
}
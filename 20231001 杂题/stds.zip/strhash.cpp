#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<ctime>
#include<vector>
#include<queue>
#include<algorithm>
#include<string>
#include<sstream>
#include<cctype>
#include<cmath>
#include<iomanip>
#include<map>
#include<stack>
#include<set>
#include<functional>
#include<unordered_map>
#include<unordered_set>
#define in(x) x=read()
#define qr read()
#define int ll
#define mp make_pair
#define nc getchar
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
namespace fastIO
{
    #define BUF_SIZE 100000
    bool IOerror=0;
    /*
    inline char nc()
	{
        static char buf[BUF_SIZE],*p1=buf+BUF_SIZE,*pend=buf+BUF_SIZE;
        if (p1==pend){
            p1=buf; pend=buf+fread(buf,1,BUF_SIZE,stdin);
            if (pend==p1){IOerror=1;return -1;}
        }
        return *p1++;
    }
    */
    inline bool blank(char ch){return ch==' '||ch=='\n'||ch=='\r'||ch=='\t';}
    inline ll read()
	{
        bool sign=0; char ch=nc();ll x=0;
        for (;blank(ch);ch=nc());
        if (IOerror)return 0;
        if (ch=='-')sign=1,ch=nc();
        for (;ch>='0'&&ch<='9';ch=nc())x=x*10+ch-'0';
        if (sign)x=-x;
        return x;
    }
    #undef BUF_SIZE
};
using namespace fastIO;
#define base 2333333
#define mod 998244353
#define blk 4702
int a[5000010],po[2000010],ipo[2000010],w[2000010];
unordered_set<int>s;
int qpow(int n,int k)
{
	int ans=1;
	while(k)
	{
		if(k&1)ans*=n,ans%=mod;
		n*=n,n%=mod;
		k>>=1;
	}
	return ans;
}
signed main()
{
	freopen("strhash.in","r",stdin);
	freopen("strhash.out","w",stdout);
	int T=qr;
	while(T--)
	{
		char ch=nc();
        for(;blank(ch);ch=nc());
        int n=0;
        for(;isalpha(ch);ch=nc())a[++n]=ch-'a'+1;
        po[0]=1;
        for(int i=1;i<=n;i++)po[i]=po[i-1]*base%mod;
        ipo[n]=qpow(po[n],mod-2);
        for(int i=n-1;i>=0;i--)ipo[i]=ipo[i+1]*base%mod;
        for(int i=1;i<=n;i++)w[i]=w[i-1]*base+a[i],w[i]%=mod;
        if(n<=blk)
        {
        	int ans=0;
        	for(int i=1;i<=n;i++)
        	{
        		for(int j=i;j<=n;j++)
        		{
        			ans=max(ans,(w[j]-w[i-1]*po[j-i+1]%mod+mod)%mod);
				}
			}
			cout<<ans<<"\n";
		}
		else
		{
			for(int ans=mod-1;ans>=0;ans--)
			{
				int f=0;
				s.clear();
				for(int i=2;i<=n;i++)
				{
					s.insert(w[i-1]*ipo[i-1]%mod);
					if(s.count((w[i]-ans+mod)*ipo[i]%mod))
					{
						f=1;
						break;
					}
				}
				if(f)
				{
					cout<<ans<<"\n";
					break;
				}
			}
		}
	}
	return 0;
}
//һ��������ֵģ���ͬ��Ѫ������� 
//seriously??

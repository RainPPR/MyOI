#include<cstdio>
#include<iostream>
#include<queue>
#include<algorithm>
#define RI register int
#define CI const int&
using namespace std;
typedef long long LL;
const int N=500005,INF=1e9;
const int mod1=998244353,mod2=1e9+7;
struct Hasher
{
	int x,y;
	inline Hasher(CI X=0,CI Y=0)
	{
		x=X; y=Y;
	}
	inline LL get_val(void)
	{
		return ((1LL*x)<<31LL)|(1LL*y);
	}
	friend inline bool operator == (const Hasher& A,const Hasher& B)
	{
		return A.x==B.x&&A.y==B.y;
	}
	friend inline Hasher operator + (const Hasher& A,const Hasher& B)
	{
		return Hasher((A.x+B.x)%mod1,(A.y+B.y)%mod2);
	}
	friend inline Hasher operator - (const Hasher& A,const Hasher& B)
	{
		return Hasher((A.x-B.x+mod1)%mod1,(A.y-B.y+mod2)%mod2);
	}
	friend inline Hasher operator * (const Hasher& A,const Hasher& B)
	{
		return Hasher(1LL*A.x*B.x%mod1,1LL*A.y*B.y%mod2);
	}
}h[N],pw[N]; deque <char> dq; char s[N]; int n,m,qq,d[N],l[N],r[N],ans[N];
const Hasher seed=Hasher(31,131);
inline Hasher get(CI l,CI r)
{
	return h[r]-h[l-1]*pw[r-l+1];
}
struct ifo
{
	int p,t,id;
	inline ifo(CI P=0,CI T=0,CI ID=0)
	{
		p=P; t=T; id=ID;
	}
	friend inline bool operator < (const ifo& A,const ifo& B)
	{
		return A.t>B.t;
	}
}o[N];
struct ques
{
	int k,l,r,id;
	inline ques(CI K=0,CI L=0,CI R=0,CI ID=0)
	{
		k=K; l=L; r=R; id=ID;
	}
	friend inline bool operator < (const ques& A,const ques& B)
	{
		return A.k>B.k;
	}
}q[N];
class Segment_Tree
{
	private:
		int mi[N<<2];
		inline void pushup(CI now)
		{
			mi[now]=min(mi[now<<1],mi[now<<1|1]);
		}
	public:
		#define TN CI now=1,CI l=1,CI r=m
		#define LS now<<1,l,mid
		#define RS now<<1|1,mid+1,r
		inline void build(TN)
		{
			mi[now]=INF; if (l==r) return; int mid=l+r>>1; build(LS); build(RS);
		}
		inline void updata(CI pos,CI mv,TN)
		{
			if (l==r) return (void)(mi[now]=mv); int mid=l+r>>1;
			if (pos<=mid) updata(pos,mv,LS); else updata(pos,mv,RS); pushup(now);
		}
		inline int query(CI beg,CI end,TN)
		{
			if (beg<=l&&r<=end) return mi[now]; int mid=l+r>>1,ret=INF;
			if (beg<=mid) ret=min(ret,query(beg,end,LS)); if (end>mid) ret=min(ret,query(beg,end,RS)); return ret;
		}
		#undef TN
		#undef LS
		#undef RS
}SEG;
int main()
{
	//freopen("H.in","r",stdin); freopen("H.out","w",stdout);
	RI i,j; for (scanf("%d%s",&n,s+1),i=1;i<=n;++i)
	if ('A'<=s[i]&&s[i]<='Z') dq.push_back(s[i]-'A'+'a');
	else dq.push_front(s[i]),d[i-1]=1;
	for (i=n;i>=1;--i) d[i]+=d[i+1],l[i]=1+d[i],r[i]=i+d[i];
	//for (i=1;i<=n;++i) printf("%d %d\n",l[i],r[i]);
	for (i=1;i<=n;++i) s[i]=dq.front(),dq.pop_front();
	for (pw[0]=Hasher(1,1),i=1;i<=n;++i) pw[i]=pw[i-1]*seed;
	for (i=1;i<=n;++i) h[i]=h[i-1]*seed+Hasher(s[i],s[i]);
	for (scanf("%d",&m),i=1;i<=m;++i)
	{
		scanf("%d",&o[i].p); int L=o[i].p,R=n,mid,ret;
		while (L<=R)
		{
			mid=L+R>>1; int len=mid-o[i].p;
			if (get(l[mid],l[mid]+len-1)==get(r[mid]-len+1,r[mid]))
			ret=mid,L=mid+1; else R=mid-1;
		}
		o[i].t=ret; o[i].id=i;
		//printf("%d %d\n",o[i].p,o[i].t);
	}
	for (scanf("%d",&qq),i=1;i<=qq;++i)
	scanf("%d%d%d",&q[i].k,&q[i].l,&q[i].r),q[i].id=i;
	sort(o+1,o+m+1); sort(q+1,q+qq+1); SEG.build();
	for (i=j=1;i<=qq;++i)
	{
		while (j<=m&&o[j].t>=q[i].k) SEG.updata(o[j].id,o[j].p),++j;
		int tmp=SEG.query(q[i].l,q[i].r); ans[q[i].id]=tmp<=q[i].k?tmp:-1;
	}
	for (i=1;i<=qq;++i) printf("%d\n",ans[i]);
	return 0;
}
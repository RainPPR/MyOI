#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<ctime>
#include<vector>
#include<queue>
#include<algorithm>
#include<string>
#include<sstream>
#include<cctype>
#include<cmath>
#include<iomanip>
#include<map>
#include<stack>
#include<set>
#include<functional>
#include<cassert>
#include<unordered_map>
#include<unordered_set>
#define in(x) x=read()
#define qr read()
#define int ll
#define mp make_pair
#define pii pair<int,int>
#define fi first
#define se second
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
namespace fastIO
{
    #define BUF_SIZE 100000
    bool IOerror=0;
    inline char nc()
	{
        static char buf[BUF_SIZE],*p1=buf+BUF_SIZE,*pend=buf+BUF_SIZE;
        if (p1==pend){
            p1=buf; pend=buf+fread(buf,1,BUF_SIZE,stdin);
            if (pend==p1){IOerror=1;return -1;}
        }
        return *p1++;
    }
    inline bool blank(char ch){return ch==' '||ch=='\n'||ch=='\r'||ch=='\t';}
    inline ll read()
	{
        bool sign=0; char ch=nc();ll x=0;
        for (;blank(ch);ch=nc());
        if (IOerror)return 0;
        if (ch=='-')sign=1,ch=nc();
        for (;ch>='0'&&ch<='9';ch=nc())x=x*10+ch-'0';
        if (sign)x=-x;
        return x;
    }
    #undef BUF_SIZE
};
using namespace fastIO;
#define mod 998244353
queue<int>q;
int a[1000010],vis[1000010],deg[1000010];
vector<int>e[1000010];
signed main()
{
	//freopen(".in","r",stdin);
	//freopen(".out","w",stdout);
	int T=qr;
	while(T--)
	{
		int n=qr,m=qr;
		for(int i=1;i<=n;i++)in(a[i]),deg[i]=0,e[i].clear();
		for(int i=1;i<=m;i++)
		{
			int x=qr,y=qr;
			e[x].push_back(y);
			deg[y]++;
		}
		int g=0;
		for(int i=1;i<=m;i++)
		{
			for(int j=1;j<=n;j++)
			{
				vis[j]=0;
				if(a[j]!=0)vis[j]=1;
			}
			int f=0;
			for(int j=1;j<=n;j++)
			{
				if(vis[j])
				{
					f=1;
					a[j]--;
					for(auto k:e[j])a[k]++;
				}
			}
			if(!f)
			{
				cout<<i-1<<'\n';
				g=1;
				break;
			}
		}
		if(g)continue;
		for(int i=1;i<=n;i++)if(!deg[i])q.push(i);
		while(!q.empty())
		{
			int now=q.front();q.pop();
			// cout<<"now="<<now<<'\n';
			for(auto i:e[now])
			{
				a[i]+=a[now],a[i]%=mod;
				deg[i]--;
				if(!deg[i])q.push(i);
			}
			if(e[now].empty())cout<<(a[now]+m)%mod<<'\n';
		}
		// cout<<'\n';
	}
	return 0;
}
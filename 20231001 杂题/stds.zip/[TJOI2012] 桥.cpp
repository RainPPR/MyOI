#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<ctime>
#include<vector>
#include<queue>
#include<algorithm>
#include<string>
#include<sstream>
#include<cctype>
#include<cmath>
#include<iomanip>
#include<map>
#include<stack>
#include<set>
#include<functional>
#define in(x) x=read()
#define qr read()
#define int ll
#define mp make_pair
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
namespace fastIO
{
    #define BUF_SIZE 100000
    bool IOerror=0;
    inline char nc()
	{
        static char buf[BUF_SIZE],*p1=buf+BUF_SIZE,*pend=buf+BUF_SIZE;
        if (p1==pend){
            p1=buf; pend=buf+fread(buf,1,BUF_SIZE,stdin);
            if (pend==p1){IOerror=1;return -1;}
        }
        return *p1++;
    }
    inline bool blank(char ch){return ch==' '||ch=='\n'||ch=='\r'||ch=='\t';}
    inline ll read()
	{
        bool sign=0; char ch=nc();ll x=0;
        for (;blank(ch);ch=nc());
        if (IOerror)return 0;
        if (ch=='-')sign=1,ch=nc();
        for (;ch>='0'&&ch<='9';ch=nc())x=x*10+ch-'0';
        if (sign)x=-x;
        return x;
    }
    #undef BUF_SIZE
};
using namespace fastIO;
struct edge
{
	int v,w;
};
vector<edge>e[500010]; 
int vis[500010],dis[500010][2];
struct node
{
	int v,dis;
	bool operator < (const node& bb)const{return dis>bb.dis;}
};
priority_queue<node>q;
int n,m,now,p[500010];
void dij(int x,int id)
{
	for(int i=1;i<=n;i++)vis[i]=0,dis[i][id]=1e16;
	dis[x][id]=0;
	q.push((node){x,0});
	while(!q.empty())
	{
		node now=q.top();q.pop();
		if(vis[now.v])continue;
		vis[now.v]=1;
		for(auto i:e[now.v])
		{
			if(dis[i.v][id]>dis[now.v][id]+i.w)
			{
				dis[i.v][id]=dis[now.v][id]+i.w;
				q.push((node){i.v,dis[i.v][id]});
			}
		}
	}
}
int id[500010];
void findpath()
{
	int x=1;
	p[1]=1;
	id[1]=1;
	now=1;
	while(x!=n)
	{
		for(auto i:e[x])
		{
			if(dis[i.v][1]+i.w==dis[x][1])
			{
				p[++now]=i.v;
				id[i.v]=now;
				x=i.v;
				break;
			}
		}
	}
}
queue<int>qq;
int pos[500010][2];
void bfs(int x,int ii)
{
	pos[x][ii]=x;
	qq.push(x);
	while(!qq.empty())
	{
		int now=qq.front();qq.pop();
		for(auto i:e[now])
		{
			if(dis[now][ii]+i.w==dis[i.v][ii]&&!id[i.v]&&!vis[i.v])pos[i.v][ii]=x,qq.push(i.v),vis[i.v]=1;
		}
	}
}
int c[500010];
int col[500010],ti[1000010];
void pushup(int x){c[x]=max(c[x<<1],c[x<<1|1]);}
void build(int l,int r,int x)
{
	col[x]=10000000000000000;
	if(l==r)
	{
		col[x]=10000000000000000;
		c[x]=ti[l];
		return;
	}
	int mid=(l+r)/2;
	build(l,mid,x<<1);
	build(mid+1,r,x<<1|1);
	pushup(x);
}
void pushdown(int x)
{
	if(col[x]!=10000000000000000)
	{
		col[x<<1]=min(col[x],col[x<<1]);
		c[x<<1]=min(col[x],c[x<<1]);
		c[x<<1|1]=min(col[x],c[x<<1|1]);
		col[x<<1|1]=min(col[x],col[x<<1|1]);
		col[x]=10000000000000000;
	}
}
void modify(int nl,int nr,int l,int r,int v,int x)
{
	if(l>r)return;
	if(l<=nl&&nr<=r)
	{
		col[x]=min(col[x],v);
		c[x]=min(c[x],v);
		return;
	}
	int mid=(nl+nr)/2;
	pushdown(x);
	if(l<=mid)modify(nl,mid,l,r,v,x<<1);
	if(r>mid)modify(mid+1,nr,l,r,v,x<<1|1);
	pushup(x);
}
void dfs(int l,int r,int x)
{
	if(l==r)return;
	int mid=(l+r)/2;
	dfs(l,mid,x<<1);
	dfs(mid+1,r,x<<1|1);
}
int query(int l,int r,int p,int x)
{
	if(l==r)return c[x];
	int mid=(l+r)/2;
	pushdown(x);
	if(p<=mid)return query(l,mid,p,x<<1);
	else return query(mid+1,r,p,x<<1|1);
}
int yes[500010],cov[500010];
struct eg
{
	int u,v,w,c,t;
};
vector<eg>ee;
signed main()
{
//	freopen("france.in","r",stdin);
//	freopen("france.out","w",stdout);
	n=qr,m=qr;
	for(int i=1;i<=m;i++)
	{
		int x=qr,y=qr,z=qr,c=qr,t=qr;
		e[x].push_back((edge){y,z});
		e[y].push_back((edge){x,z});
		ee.push_back((eg){x,y,z,c,t});
	}
	dij(1,0);
	dij(n,1);
	findpath();
	int siz=ee.size();	
	for(int i=0;i<siz;i++)
	{
		if(id[ee[i].u]>id[ee[i].v])swap(ee[i].u,ee[i].v);
		if(id[ee[i].u]&&id[ee[i].v]&&id[ee[i].u]+1==id[ee[i].v]&&dis[ee[i].u][0]+ee[i].w==dis[ee[i].v][0]&&!cov[id[ee[i].u]])
		{
			if(ee[i].c==1)ti[id[ee[i].u]]=10000000000000000;
			else ti[id[ee[i].u]]=dis[n][0]+ee[i].t;
			cov[id[ee[i].u]]=1;
			yes[i]=1;
		}
	}
	for(int i=1;i<=n;i++)vis[i]=0;
	for(int i=1;i<=now;i++)bfs(p[i],0);
	for(int i=1;i<=n;i++)vis[i]=0;
	for(int i=now;i>=1;i--)bfs(p[i],1);
	build(1,now-1,1);
	for(int i=0;i<siz;i++)
	{
		if(!yes[i])
		{
			modify(1,now-1,id[pos[ee[i].u][0]],id[pos[ee[i].v][1]]-1,dis[ee[i].u][0]+ee[i].w+dis[ee[i].v][1],1);
			modify(1,now-1,id[pos[ee[i].v][0]],id[pos[ee[i].u][1]]-1,dis[ee[i].v][0]+ee[i].w+dis[ee[i].u][1],1);
		}
	}
	if(c[1]>=1000000000000000)puts("vive la france");
	else cout<<c[1]<<'\n';
	if(c[1]==dis[n][0])return cout<<m,0;
	int ans=0;
	for(int i=1;i<now;i++)
	{
		if(query(1,now-1,i,1)==c[1])ans++;
	}
	cout<<ans<<'\n';
	return 0;
}
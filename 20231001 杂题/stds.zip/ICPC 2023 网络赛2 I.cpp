const int maxn = 500010;
//const int mod = 998244353;

int n;
//int x, k;
int a[maxn];

void solve() {
    scanf("%d", &n);
    for (int i = 0; i < n; ++i) {
        scanf("%d", &a[i]); 
    }

    double res = n;
    int p;
    for (int i = 0; i < n; ++i) {
        scanf("%d", &p);
        if (!p) {
            continue;
        }
        double q = 1.0 * p / 100000;
        // 先走i步走到 第i位置；
        // 花费1次"赌命"，看是否成功；共花费i + 1 
        // 成功的期望次数为1/q次 所以需要1/q-1次失败，
        // 每次失败，需要走 i-a[i]+1次，多的一次是用来"赌命" 
        dp[i] = 1.0 * i + 1 + (1.0 / q - 1) * (i - a[i] + 1);
        res = min(dp[i], res);
    }
    if (debugging) {
        for (int i = 0; i < n; ++i) {
            printf("dp[%d]:%.12f\n", i, dp[i]); 
        }
    }
    printf("%.12f\n", res);
}
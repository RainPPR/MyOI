#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<ctime>
#include<vector>
#include<queue>
#include<algorithm>
#include<string>
#include<sstream>
#include<cctype>
#include<cmath>
#include<iomanip>
#include<map>
#include<stack>
#include<set>
#include<functional>
#include<unordered_map>
#define in(x) x=read()
#define qr read()
#define int ll
#define mp make_pair
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
namespace fastIO
{
    #define BUF_SIZE 100000
    bool IOerror=0;
    inline char nc()
	{
        static char buf[BUF_SIZE],*p1=buf+BUF_SIZE,*pend=buf+BUF_SIZE;
        if (p1==pend){
            p1=buf; pend=buf+fread(buf,1,BUF_SIZE,stdin);
            if (pend==p1){IOerror=1;return -1;}
        }
        return *p1++;
    }
    inline bool blank(char ch){return ch==' '||ch=='\n'||ch=='\r'||ch=='\t';}
    inline ll read()
	{
        bool sign=0; char ch=nc();ll x=0;
        for (;blank(ch);ch=nc());
        if (IOerror)return 0;
        if (ch=='-')sign=1,ch=nc();
        for (;ch>='0'&&ch<='9';ch=nc())x=x*10+ch-'0';
        if (sign)x=-x;
        return x;
    }
    #undef BUF_SIZE
};
using namespace fastIO;
char a[1000010];
char b[1010][1010];
int c[11];
int f[1010][1010][2],w[1010][1010][11],sum[1010][1010][11],pos[1010][11];
struct node
{
	int x,id;
}d[1000010],e[1000010];
bool cmp(node d1,node d2)
{
	return d1.x>d2.x;
}
int biden[1000010];
signed main()
{
//	freopen("digits.in","r",stdin);
//	freopen("digits.out","w",stdout);
	cin>>a+1;
	int mx=strlen(a+1);
	int len=strlen(a+1);
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>b[i]+1;
		biden[i]=strlen(b[i]+1);
		mx=max(mx,int(strlen(b[i]+1)));
	}
	mx++;
	for(int i=1;i<=len/2;i++)swap(a[i],a[len+1-i]);
	for(int i=len+1;i<=mx;i++)a[i]='0';
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=biden[i]/2;j++)swap(b[i][j],b[i][biden[i]+1-j]);
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=biden[i]+1;j<=mx;j++)b[i][j]='0';
		biden[i]=max(biden[i],len);
//		for(int j=1;j<=mx;j++)cout<<b[i][j]<<' ';cout<<'\n';
	}
	for(int i=0;i<10;i++)cin>>c[i];
	c[10]=0;
	for(int i=1;i<=n;i++)d[i].id=i,d[i].x=0;
	for(int i=1;i<=mx;i++)
	{
		for(int j=0;j<=n;j++)f[i][j][0]=f[i][j][1]=-2e9;
	}
	for(int i=1;i<=n;i++)
	{
		f[0][i][0]=f[0][i][1]=0;
	}
	for(int i=1;i<=mx;i++)
	{
		for(int j=1;j<=n;j++)e[j].x=d[j].x,e[j].id=d[j].id;
//		for(int j=1;j<=n;j++)cout<<e[j].id<<' ';cout<<'\n';
		for(int j=1;j<=n;j++)d[j].x=b[e[j].id][i];
		stable_sort(d+1,d+1+n,cmp);
		for(int j=1;j<=n;j++)
		{
			if(i<=biden[j])
		for(int k=0;k<10;k++)
		{
			w[i][0][k]+=c[(b[j][i]-'0'+k)%10];
		}
		}
		for(int j=1;j<=n;j++)if(i<=biden[j])sum[i][0][(b[j][i]-'0')%10]++;
		if(i==1)
		{
			for(int j=1;j<=n;j++)
			{
				for(int k=0;k<10;k++)w[i][j][k]=w[i][0][k],sum[i][j][k]=sum[i][0][k];
			}
			for(int j=0;j<=n;j++)
			{
				pos[j][0]=0;
				for(int k=1;k<10;k++)
				{
					pos[j][k]=pos[j][k-1]+sum[i][j][10-k];
				}
			}
		}
		else
		{
			for(int j=0;j<=n;j++)pos[j][0]=0;
			for(int j=1;j<=n;j++)
			{
				pos[j][0]=pos[j-1][0];
				for(int k=0;k<10;k++)sum[i][j][k]=sum[i][j-1][k];
				for(int k=0;k<10;k++)
				{
					if(i<=biden[e[j].id])w[i][j][k]=w[i][j-1][k]-c[(b[e[j].id][i]-'0'+k)%10]+c[(b[e[j].id][i]-'0'+1+k)%10];
					else
					{
						if(i==biden[e[j].id]+1)w[i][j][k]=w[i][j-1][k]+c[1];
						else w[i][j][k]=w[i][j-1][k];
					}
				}
				if(i<=biden[e[j].id]){sum[i][j][(b[e[j].id][i]-'0')%10]--;}
				if(i<=biden[e[j].id])sum[i][j][(b[e[j].id][i]-'0'+1)%10]++;
				else
				{
					if(i==biden[e[j].id]+1)sum[i][j][1]++;
				}
				if(i<=biden[e[j].id])if((b[e[j].id][i]-'0'+1)%10==0)pos[j][0]++;
			}
			for(int j=0;j<=n;j++)
			{
				for(int k=1;k<10;k++)
				{
					pos[j][k]=pos[j][k-1]+sum[i][j][10-k];
				}
			}
		}
		
		
		if(a[i]=='?')
		{
		for(int j=0;j<=n;j++)
		{
			for(int k=1;k<10;k++)
			{
//				cout<<k<<":"<<i-1<<','<<j<<",1->"<<i<<','<<pos[j][k]<<",1("<<f[i-1][j][1]<<"+"<<w[i][j][k]<<")\n";
//				cout<<k<<":"<<i-1<<','<<j<<",0->"<<i<<','<<pos[j][k]<<",1("<<f[i-1][j][0]<<"+"<<w[i][j][k]<<")\n";
				f[i][pos[j][k]][1]=max(f[i][pos[j][k]][1],f[i-1][j][1]+w[i][j][k]);
				f[i][pos[j][k]][1]=max(f[i][pos[j][k]][1],f[i-1][j][0]+w[i][j][k]);
			}
			if(i!=len)
			{
//				cout<<0<<":"<<i-1<<','<<j<<",1->"<<i<<','<<0<<",1("<<f[i-1][j][1]<<"+"<<w[i][j][0]<<")\n";
//				cout<<0<<":"<<i-1<<','<<j<<",0->"<<i<<','<<0<<",1("<<f[i-1][j][0]<<"+"<<w[i][j][0]<<")\n";
			f[i][pos[j][0]][0]=max(f[i][pos[j][0]][0],f[i-1][j][1]+w[i][j][0]);
			f[i][pos[j][0]][0]=max(f[i][pos[j][0]][0],f[i-1][j][0]+w[i][j][0]);
			}
		}
		}
		else
		{
		for(int j=0;j<=n;j++)
		{
			if(a[i]-'0')
			{
//				cout<<a[i]-'0'<<":"<<i-1<<','<<j<<",1->"<<i<<','<<pos[j][a[i]-'0']<<",1("<<f[i-1][j][1]<<"+"<<w[i][j][a[i]-'0']<<")\n";
//				cout<<a[i]-'0'<<":"<<i-1<<','<<j<<",0->"<<i<<','<<pos[j][a[i]-'0']<<",1("<<f[i-1][j][0]<<"+"<<w[i][j][a[i]-'0']<<")\n";
			f[i][pos[j][a[i]-'0']][1]=max(f[i][pos[j][a[i]-'0']][1],f[i-1][j][1]+w[i][j][a[i]-'0']);
			f[i][pos[j][a[i]-'0']][1]=max(f[i][pos[j][a[i]-'0']][1],f[i-1][j][0]+w[i][j][a[i]-'0']);
			}
			else
			{
//				cout<<0<<":"<<i-1<<','<<j<<",1->"<<i<<','<<0<<",0("<<f[i-1][j][1]<<"+"<<w[i][j][0]<<")\n";
//				cout<<0<<":"<<i-1<<','<<j<<",0->"<<i<<','<<0<<",0("<<f[i-1][j][0]<<"+"<<w[i][j][0]<<")\n";
			f[i][pos[j][0]][0]=max(f[i][pos[j][0]][0],f[i-1][j][1]+w[i][j][0]);
			f[i][pos[j][0]][0]=max(f[i][pos[j][0]][0],f[i-1][j][0]+w[i][j][0]);
			}
		}
		}
	}//cout<<endl;
	/*
	for(int i=1;i<=n;i++)
	{
		for(int j=0;j<=n;j++)cout<<w[i][j][0]<<" ";cout<<"\n";
	}
	
	for(int i=1;i<=mx;i++)
	{
		for(int j=0;j<=n;j++)
		{
			cout<<f[i][j][0]<<','<<f[i][j][1]<<" ";
		}cout<<'\n';
	}
	*/
	int ans=0;
	for(int i=0;i<=n;i++)
	{
		ans=max(ans,max(f[mx][i][0],f[mx][i][1]));
	}
	cout<<ans;
	return 0;
}
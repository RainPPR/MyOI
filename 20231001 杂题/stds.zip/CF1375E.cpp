#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define mk make_pair
#define lob lower_bound
#define upb upper_bound
#define fi first
#define se second
#define SZ(x) ((int)(x).size())

typedef unsigned int uint;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> pii;

const int MAXN=1000;
int n,a[MAXN+5],vals[MAXN+5],cnt_val,p[MAXN+5],pos[MAXN+5];
vector<pii>ans;
void work(int p1,int p2){
	assert(pos[a[p1]]==p1);assert(pos[a[p2]]==p2);
	pos[a[p1]]=p2;
	pos[a[p2]]=p1;
	swap(a[p1],a[p2]);
	ans.pb(mk(p1,p2));
}
int main() {
	cin>>n;
	for(int i=1;i<=n;++i)cin>>a[i],vals[++cnt_val]=a[i];
	sort(vals+1,vals+cnt_val+1);
	cnt_val=unique(vals+1,vals+cnt_val+1)-(vals+1);
	int x=0;
	for(int v=1;v<=cnt_val;++v){
		for(int i=1;i<=n;++i)
			if(a[i]==vals[v])
				p[i]=++x;
	}
	for(int i=1;i<=n;++i)a[i]=p[i];
	assert(x==n);
	//于是a变成了一个排列
	for(int i=1;i<=n;++i)pos[a[i]]=i;
	for(int i=n;i>=1;--i){
		for(int j=a[i]+1;j<=i;++j){
			work(pos[j],i);
		}
	}
	cout<<SZ(ans)<<endl;
	for(int i=0;i<SZ(ans);++i)cout<<ans[i].fi<<" "<<ans[i].se<<endl;
	return 0;
}
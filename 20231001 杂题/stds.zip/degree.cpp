#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<ctime>
#include<vector>
#include<queue>
#include<algorithm>
#include<string>
#include<sstream>
#include<cctype>
#include<cmath>
#include<iomanip>
#include<map>
#include<stack>
#include<set>
#include<functional>
#include<unordered_map>
#define in(x) x=read()
#define qr read()
#define int ll
#define mp make_pair
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
namespace fastIO
{
    #define BUF_SIZE 100000
    bool IOerror=0;
    inline char nc()
	{
        static char buf[BUF_SIZE],*p1=buf+BUF_SIZE,*pend=buf+BUF_SIZE;
        if (p1==pend){
            p1=buf; pend=buf+fread(buf,1,BUF_SIZE,stdin);
            if (pend==p1){IOerror=1;return -1;}
        }
        return *p1++;
    }
    inline bool blank(char ch){return ch==' '||ch=='\n'||ch=='\r'||ch=='\t';}
    inline ll read()
	{
        bool sign=0; char ch=nc();ll x=0;
        for (;blank(ch);ch=nc());
        if (IOerror)return 0;
        if (ch=='-')sign=1,ch=nc();
        for (;ch>='0'&&ch<='9';ch=nc())x=x*10+ch-'0';
        if (sign)x=-x;
        return x;
    }
    #undef BUF_SIZE
};
using namespace fastIO;
int fa[1000010],fa2[1000010];
int bel[1000010];
int x[1000010],y[1000010],vis[1000010],oud[1000010],ans[1000010];
struct edge
{
	int v,id;
};
vector<edge>e[1000010],e2[1000010];
int tim=0,dfn[1000010],low[1000010],bg[1000010];
void tarjan(int u,int pre)
{
	dfn[u]=low[u]=++tim;
	for(auto i:e[u])
	{
		if(!dfn[i.v])
		{
			tarjan(i.v,i.id/2);
			low[u]=min(low[u],low[i.v]);
			if(low[i.v]>dfn[u])bg[i.id]=bg[i.id^1]=1;
		}
		else if(i.id/2!=pre)
		{
			low[u]=min(low[u],dfn[i.v]);
		}
	}
}
int idd=0;
void dfs(int x)
{
//	cout<<x<<" "<<idd<<endl;
	bel[x]=idd;
	for(auto i:e[x])
	{
		if(!bg[i.id]&&!vis[i.id/2])
		{
			ans[i.id/2]=i.id%2;
			vis[i.id/2]=1;
			dfs(i.v);
		}
	}
}
int f[1000010];//0:true 00 1:10 2:01 3:fake 00
int id[2][2]={{0,2},{1,3}},g=0;
int son1[1000010],son2[1000010],p1[1000010],p2[1000010],org[1000010];
int up[1000010];//0:up 1:down
void dfs2(int u,int pre)
{
	for(auto i:e2[u])
	{
		if(i.v==pre)continue;
		dfs2(i.v,u);
	}
	if(x[u]==0&&y[u]==0)
	{
		f[u]=0;
	}
	int ind=0,oud=0;
	son1[u]=0,son2[u]=0;
	p1[u]=0,p2[u]=0;
	for(auto i:e2[u])
	{
		if(i.v==pre)continue;
		if(f[i.v]==1)
		{
			up[i.v]=1;
			ans[i.id/2]=i.id%2;
			oud++;
		}
		else if(f[i.v]==2)
		{
			up[i.v]=0;
			ans[i.id/2]=(i.id&1)^1;
			ind++;
		}
		else
		{
			if(!son1[u])son1[u]=i.v,p1[u]=i.id;
			else if(!son2[u])son2[u]=i.v,p2[u]=i.id;
			if(i.id%2)up[i.v]=0;
			else up[i.v]=1;	
		}
	}
	int nx=x[u],ny=y[u];
	if(ind)nx=0;
	if(oud)ny=0;
	if(nx==0&&ny==0)
	{
		f[u]=0;
		return;
	}
	if(!p1[u])
	{
		if(nx==1&&ny==1)
		{
			g=1;
			return;
		}
		f[u]=id[nx][ny];
	}
	else
	{
		if(!p2[u]&&nx==1&&ny==1)
		{
			f[u]=3;
			return;
		}
		else
		{
			org[u]=id[nx][ny];
			f[u]=0;
		}
	}
}
void dfs3(int u,int pre)
{
	if(f[u]==3)
	{
		if(up[u])
		{
			ans[p1[u]/2]=p1[u]%2;
		}
		else ans[p1[u]/2]=(p1[u]&1)^1;
		up[son1[u]]=up[u];
	}
	else if(f[u]==0&&org[u]!=0)
	{
		if(org[u]==1)
		{
			ans[p1[u]/2]=(p1[u]&1)^1;
			up[son1[u]]=0;
		}
		else if(org[u]==2)
		{
			ans[p1[u]/2]=(p1[u]&1);
			up[son1[u]]=1;
		}
		else
		{
			ans[p1[u]/2]=(p1[u]&1)^1;
			up[son1[u]]=0;
			ans[p2[u]/2]=(p2[u]&1);
			up[son2[u]]=1;
		}
	}
	for(auto i:e2[u])
	{
		if(i.v==pre)continue;
		dfs3(i.v,u);
	}
}
int u[1000010],v[1000010],cnt[1000010],tx[1000010],ty[1000010],fakenews[1000010];
signed main()
{
	freopen("degree.in","r",stdin);
	freopen("degree.out","w",stdout);
	int n=qr,m=qr;
	for(int i=1;i<=n;i++)in(x[i]);
	for(int i=1;i<=n;i++)in(y[i]);
	for(int i=1;i<=m;i++)
	{
		int x=qr,y=qr;
		e[x].push_back((edge){y,2*i+1});
		e[y].push_back((edge){x,2*i});
		u[i]=x,v[i]=y;
	}
	tarjan(1,0);
	for(int i=1;i<=n;i++)
	{
		if(!bel[i])
		{
			idd++;
			dfs(i);
		}
	}
	for(int i=1;i<=m;i++)
	{
		int a=bel[u[i]],b=bel[v[i]];
		if(a!=b)
		{
//			cout<<a<<"-"<<b<<"\n";
			e2[a].push_back((edge){b,2*i+1});
			e2[b].push_back((edge){a,2*i});
		}
	}
	for(int i=1;i<=n;i++)cnt[bel[i]]++,fakenews[bel[i]]=i;
	for(int i=1;i<=idd;i++)
	{
		if(cnt[i]==1)
		{
			tx[i]=x[fakenews[i]],ty[i]=y[fakenews[i]];
		}
		else tx[i]=ty[i]=0;
//		cout<<tx[i]<<','<<ty[i]<<"\n";
	}
	for(int i=1;i<=idd;i++)x[i]=tx[i],y[i]=ty[i];
	dfs2(bel[1],bel[1]);
//	for(int i=1;i<=2*m;i++)cout<<bg[i]<<' ';cout<<endl;
//	for(int i=1;i<=n;i++)cout<<bel[i]<<' ';cout<<endl;
//	for(int i=1;i<=idd;i++)cout<<f[i]<<' ';cout<<"\n";
//	cout<<g<<endl;
	if(g)return puts("-1"),0;
	if(f[bel[1]]!=0)return puts("-1"),0;
	dfs3(bel[1],bel[1]);
	for(int i=1;i<=m;i++)cout<<(ans[i])<<' ';
	return 0;
}
//������Ȼ������ ɽ��ȴ��֪��

#include<bits/stdc++.h> 
using namespace std;
const int N=1e5+5;
int n,d,T,dp[N][2];
char s[N],a[N][64];
int main(){
//	freopen("data/frieren5.in","r",stdin);
//	freopen("data/frieren5.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		scanf("%d%d",&n,&d);
		scanf("%s",s+1);
		for(int i=1;i<=n;++i) scanf("%s",a[i]);
		int ans=0;
		for(int i=0;i<d;++i){
			if(a[1][i]!='1') dp[1][0]=1;else dp[1][0]=0;
			if(a[1][i]!='0') dp[1][1]=1;else dp[1][1]=0;
			for(int j=2;j<=n;++j){
				dp[j][0]=dp[j][1]=0;
				if(s[j-1]=='0'){
					if(a[j][i]!='1') dp[j][0]|=dp[j-1][0]|dp[j-1][1];
					if(a[j][i]!='0') dp[j][1]|=dp[j-1][1],dp[j][0]|=dp[j-1][0];      
				}
				if(s[j-1]=='1'){
					if(a[j][i]!='0') dp[j][1]|=dp[j-1][0]|dp[j-1][1];
					if(a[j][i]!='1') dp[j][1]|=dp[j-1][1],dp[j][0]|=dp[j-1][0];      
				}
			}
			if(dp[n][0]&&dp[n][1]) ans++;
		}
		// if(ans<=63) 
		printf("%llu\n",(1llu)<<ans);
		// else puts("18446744073709551616");
	} 
	return 0;
}

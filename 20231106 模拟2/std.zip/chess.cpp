#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10,MX=5;
struct node{
	int v,nxt,c0,c1,c2;
}e[N<<1];
int T,n,mod,cnt,first[N],a[N],son[N],tot,val[N];
int mx[N][12],mn[N][12],mxs[N][12],mns[N][12],ans,ret[N];
struct element{
	int f1,f2,f3,f4;
	element(int c1=1,int c2=1,int c3=1,int c4=1){f1=c1;f2=c2;f3=c3;f4=c4;}
};
struct DP{
	element d[12];
	int sum;
	DP(){
		for(int j=1;j<=MX;++j)
			d[j]=element();
		sum=1;
	}
	element& operator [](const int &x){
		return d[x];
	}
}f[N],g[N],pre[N],suf[N],f_fa[N];
inline element operator *(const element &x,const element &y){
	return element(1ll*x.f1*y.f1%mod,1ll*x.f2*y.f2%mod,1ll*x.f3*y.f3%mod,1ll*x.f4*y.f4%mod);
}

inline DP operator *(const DP &x,const DP &y){
	DP ans;
	ans.sum=1ll*x.sum*y.sum%mod;
	for(int j=1;j<=MX;++j)
		ans.d[j]=x.d[j]*y.d[j];
	return ans;
}
inline int add(int x,int y){return (x+y>=mod)?x+y-mod:x+y;}
inline void inc(int &x,int y){x=(x+y>=mod)?x+y-mod:x+y;}
inline int dec(int x,int y){return (x-y<0)?x-y+mod:x-y;}
inline void rec(int &x,int y){x=(x-y<0)?x-y+mod:x-y;}

inline void addedge(int u,int v,int l,int r){
	int c0=l==0,c1=(r+1)/2-l/2,c2=(r-l+1)-c0-c1;
	// cout<<l<<" "<<r<<" "<<c0<<" "<<c1<<" "<<c2<<endl;
	e[++cnt]=(node){v,first[u],c0,c1,c2};first[u]=cnt;
	e[++cnt]=(node){u,first[v],c0,c1,c2};first[v]=cnt;
}
inline void dfs1(int u,int fa){
	f[u]=DP();
	for(int i=first[u];i;i=e[i].nxt){
		int v=e[i].v;
		if(v==fa) continue;
		dfs1(v,u);
		g[v].sum=1ll*(0ll+e[i].c0+e[i].c1+e[i].c2)%mod*f[v].sum%mod;
		int tmp1=1ll*e[i].c0*f[v].sum%mod,tmp2=1ll*add(e[i].c0,e[i].c2)*f[v].sum%mod;
		for(int j=1;j<=MX;++j){
			g[v][j]=element(
				add(tmp1,1ll*e[i].c2*dec(f[v].sum,mns[v][j])%mod),
				add(tmp2,1ll*e[i].c1*mn[v][j]%mod),
				add(tmp1,1ll*e[i].c2*dec(f[v].sum,mxs[v][j])%mod),
				add(tmp2,1ll*e[i].c1*mx[v][j]%mod)
			);
		}
		f[u]=f[u]*g[v];
	}
	for(int j=1;j<=MX;++j){
		mx[u][j]=mxs[u][j]=dec(f[u].sum,f[u][j].f2);
		if(a[u]>=j) inc(mx[u][j],f[u][j].f1);
		mn[u][j]=mns[u][j]=dec(f[u].sum,f[u][j].f4);
		if(a[u]<j) inc(mn[u][j],f[u][j].f3);
	}
}
inline void dfs2(int u,int fa){
	DP tmp=f_fa[u]*f[u];
	for(int j=1;j<=MX;++j){
		ret[j]=dec(tmp.sum,tmp[j].f2);
		if(a[u]>=j) inc(ret[j],tmp[j].f1);
	}
	for(int j=1;j<=MX;++j)
		inc(ans,1ll*dec(ret[j],ret[j+1])*j%mod);
	tot=0;
	for(int i=first[u];i;i=e[i].nxt){
		int v=e[i].v;
		if(v==fa) continue;
		son[++tot]=v;val[tot]=i;
	}
	pre[0]=f_fa[u];suf[tot+1]=DP();
	for(int i=1;i<=tot;++i) pre[i]=pre[i-1]*g[son[i]];
	for(int i=tot;i>=1;--i) suf[i]=suf[i+1]*g[son[i]];
	for(int i=1;i<=tot;++i){
		int v=son[i],id=val[i];
		DP tmp=pre[i-1]*suf[i+1];
		f_fa[v].sum=1ll*tmp.sum*((0ll+e[id].c0+e[id].c1+e[id].c2)%mod)%mod;
		int tmp1=1ll*e[id].c0*tmp.sum%mod,tmp2=1ll*add(e[id].c0,e[id].c2)*tmp.sum%mod;
		for(int j=1;j<=MX;++j){
			int mx=dec(tmp.sum,tmp[j].f2),mxs=mx;
			if(a[u]>=j) inc(mx,tmp[j].f1);
			int mn=dec(tmp.sum,tmp[j].f4),mns=mn;
			if(a[u]<j) inc(mn,tmp[j].f3);
			f_fa[v][j]=element(
				add(tmp1,1ll*e[id].c2*dec(tmp.sum,mns)%mod),
				add(tmp2,1ll*e[id].c1*mn%mod),
				add(tmp1,1ll*e[id].c2*dec(tmp.sum,mxs)%mod),
				add(tmp2,1ll*e[id].c1*mx%mod)
			);
		}
	}
	for(int i=first[u];i;i=e[i].nxt)
		if(e[i].v!=fa) dfs2(e[i].v,u);
}
int main(){
	freopen(".in","r",stdin);
	scanf("%d",&T);
	while(T--){
		scanf("%d%d",&n,&mod);
		cnt=0;
		memset(first+1,0,sizeof(int)*(n));
		for(int i=1;i<=n;++i) scanf("%d",&a[i]);
		for(int i=1,u,v,s,f;i<n;++i){
			scanf("%d%d%d%d",&u,&v,&s,&f);
			if(f==0) addedge(u,v,s,s);
			else addedge(u,v,0,s);
		}
		ans=0;
		dfs1(1,0);
		f_fa[1]=DP();
		dfs2(1,0);
		printf("%d\n",ans);
	}
	return 0;
}
#include<bits/stdc++.h>
using namespace std;
const int N=2e5+10;
typedef long long ll;
int id,n,q;
ll x[N],y[N];
inline ll dis(ll ax,ll ay,ll bx,ll by){
	return abs(ax-bx)+abs(ay-by);
}
inline ll S(ll n){
	return n*(n+1)/2;
}
inline ll S(ll l,ll r){
	return S(r)-S(l-1);
}
int main(){
	scanf("%d%d%d",&id,&n,&q);
	for(int i=1;i<=n;++i) scanf("%lld%lld",&x[i],&y[i]);
	for(int i=1;i<=q;++i){
		int u,v;ll lx,rx,ly,ry;bool fl=0;
		scanf("%d%d%lld%lld%lld%lld",&u,&v,&lx,&rx,&ly,&ry);
		ll ans1=0,ans2=0,ans3=0,xu=x[u],xv=x[v],yu=y[u],yv=y[v];
		ll dx=rx-lx+1,dy=ry-ly+1;
		if(xu>xv) swap(xu,xv),swap(yu,yv),fl^=1;
		if(yu>yv){
			xu=-xu;xv=-xv;
			lx=-lx;rx=-rx;swap(lx,rx);
			swap(xu,xv);swap(yu,yv);fl^=1;
		}
		ll t=dis(xv,yv,lx,ly)-dis(xu,yu,lx,ly);
		if(t<0) ans1=dx*dy;
		else if(dis(xu,yu,rx,ry)<dis(xv,yv,rx,ry)) ans2=dx*dy;
		else{
			if(t%2==0){
				ll p=t/2;
				if(dx>dy) swap(dx,dy);
				if(p<dx) ans2=S(1,p),ans3=p+1;
				else if(p<dy) ans2=S(1,dx)+dx*(p-dx),ans3=dx;
				else ans2=S(1,dx)+dx*(dy-dx)+S(dx+dy-p,dx-1),ans3=dx+dy-p-1;
				ans1=dx*dy-ans2-ans3;
			}
			else{
				ll p=t/2+1;
				if(dx>dy) swap(dx,dy);
				if(p<dx) ans2=S(1,p);
				else if(p<dy) ans2=S(1,dx)+dx*(p-dx);
				else ans2=S(1,dx)+dx*(dy-dx)+S(dx+dy-p,dx-1);
				ans1=dx*dy-ans2-ans3;
			}
		}
		if(fl) swap(ans1,ans2);
		printf("%lld %lld %lld\n",ans1,ans2,ans3);
	}
	return 0;
}

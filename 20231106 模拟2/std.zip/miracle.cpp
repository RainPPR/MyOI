//This code is a terrible implemention,so a good implemention may <5k.
//If you complete this problem in the contest,it is "Where All Miracles Begin"

#include<bits/stdc++.h>
using namespace std;
const int N=2e5+10;
typedef long long ll;
vector<int> to[N];
int id,n,q,c[N],pd[N],dfn[N],ed[N],tot,fa[N],pos[N],dep[N],pa[N][20],hson[N],siz[N],top[N];
//pos:pos on the dfn; pos~ed mean the subtree
int rt;
ll sval[N];
//the sum of the subtree in the original tree

inline bool is_ancestor(int u,int v){
	return pos[u]<=pos[v]&&pos[v]<=ed[u];
}
//Actually SGT1 and SGT2 can be merged,but that is found in the coding... 展 示 容 错 率
namespace SGT1{
	//find the first point with the prefix>sum/2 
	//require:point update
	#define lc (p<<1)
	#define rc (p<<1|1)
	#define mid ((l+r)>>1)
	ll sum[N<<2];
	inline void pushup(int p){
		sum[p]=sum[lc]+sum[rc];
	}
	inline void build(int p=1,int l=1,int r=n){
		if(l==r){
			sum[p]=c[dfn[l]];
			return ;
		}
		build(lc,l,mid);build(rc,mid+1,r);
		pushup(p);
	}
	inline void update(int p,int x,int l=1,int r=n){
		if(l==r){
			sum[p]=c[dfn[l]];
			return ;
		}
		if(x<=mid) update(lc,x,l,mid);
		else update(rc,x,mid+1,r);
		pushup(p);
	}
	inline ll query_sum(int p,int ql,int qr,int l=1,int r=n){
		if(ql<=l&&r<=qr) return sum[p];
		ll ans=0;
		if(ql<=mid) ans+=query_sum(lc,ql,qr,l,mid);
		if(qr>mid) ans+=query_sum(rc,ql,qr,mid+1,r);
		return ans;
	}
	inline int find(int p,ll v,int l=1,int r=n){
		if(l==r) return dfn[l];
		if(sum[lc]>v) return find(lc,v,l,mid);
		else return find(rc,v-sum[lc],mid+1,r);
	}
	#undef lc
	#undef rc
	#undef mid
}
namespace SGT2{
	//first maintain the sum of subtree of all the points:sum
	//then:maintain the answer of all the speical points&not ancestor
	//require:segment cover,segment add;single point update whether special;
	#define lc (p<<1)
	#define rc (p<<1|1)
	#define mid ((l+r)>>1)
	ll ans1[N<<2],ans2[N<<2];
	ll sum[N<<2],mxsum1[N<<2],mxsum2[N<<2];
	ll mxd[N<<2],add_tag[N<<2];
	int tag[N<<2];
	//sum:sum of subtree in the original tree
	//mxd:deepest special point
	//ans1:max sum of special points except the ancestors of rt
	//ans2:max sum of special points
	//mxsum1:max sum of points except the ancestors of rt
	//mxsum2:max sum of points
	//tag:=-1 no tag;=1 all not ancestor;=0 all ancestor
	inline void pushup(int p){
		ans1[p]=max(ans1[lc],ans1[rc]);
		ans2[p]=max(ans2[lc],ans2[rc]);
		mxsum1[p]=max(mxsum1[lc],mxsum1[rc]);
		mxsum2[p]=max(mxsum2[lc],mxsum2[rc]);
		mxd[p]=(dep[mxd[rc]]>dep[mxd[lc]])?mxd[rc]:mxd[lc];
	}
	inline void cov(int p,int t){
		tag[p]=t;
		if(t==0)
			ans1[p]=-1,mxsum1[p]=-1;
		else
			ans1[p]=ans2[p],mxsum1[p]=mxsum2[p];
	}
	inline void add(int p,ll t){
		add_tag[p]+=t;
		if(ans1[p]!=-1) ans1[p]+=t;
		if(mxsum1[p]!=-1) mxsum1[p]+=t;
		if(ans2[p]!=-1) ans2[p]+=t;
		if(mxsum2[p]!=-1) mxsum2[p]+=t;
		sum[p]+=t;
	}
	inline void pushdown(int p){
		if(tag[p]!=-1){
			cov(lc,tag[p]);cov(rc,tag[p]);
			tag[p]=-1;
		}
		if(add_tag[p]!=0){
			add(lc,add_tag[p]);add(rc,add_tag[p]);
			add_tag[p]=0;
		}
	}
	inline void build(int p=1,int l=1,int r=n){
		tag[p]=-1;
		if(l==r){
			sum[p]=sval[dfn[l]];
			if(pd[dfn[l]]) ans2[p]=sum[p],mxd[p]=dfn[l];
			else ans2[p]=-1,mxd[p]=0;
			if(pd[dfn[l]]&&!is_ancestor(dfn[l],rt)) ans1[p]=sum[p];
			else ans1[p]=-1;
			mxsum2[p]=sum[p];
			if(!is_ancestor(dfn[l],rt)) mxsum1[p]=sum[p];
			else mxsum1[p]=-1;
			return ;
		}
		build(lc,l,mid);build(rc,mid+1,r);
		pushup(p);
	}
	inline void update_pt(int p,int x,int l=1,int r=n){
		//single update whether special
		if(l==r){
			if(pd[dfn[l]]) ans2[p]=sum[p],mxd[p]=dfn[l];
			else ans2[p]=-1,mxd[p]=0;
			if(pd[dfn[l]]&&!is_ancestor(dfn[l],rt)) ans1[p]=sum[p];
			else ans1[p]=-1;
			return ;
		}
		pushdown(p);
		if(x<=mid) update_pt(lc,x,l,mid);
		else update_pt(rc,x,mid+1,r);
		pushup(p);
	}
	inline void add_sum(int p,int ql,int qr,ll v,int l=1,int r=n){
		//segment add sum
		if(ql<=l&&r<=qr) return add(p,v);
		pushdown(p);
		if(ql<=mid) add_sum(lc,ql,qr,v,l,mid);
		if(qr>mid) add_sum(rc,ql,qr,v,mid+1,r);
		pushup(p);
	}
	inline void cover(int p,int ql,int qr,int tg,int l=1,int r=n){
		//segment cover whether ancestor
		if(ql<=l&&r<=qr) return cov(p,tg);
		pushdown(p);
		if(ql<=mid) cover(lc,ql,qr,tg,l,mid);
		if(qr>mid) cover(rc,ql,qr,tg,mid+1,r);
		pushup(p);
	}
	inline int find_mxd(int p,int ql,int qr,int l=1,int r=n){
		//segment find deepest special point
		if(ql<=l&&r<=qr) return mxd[p];
		pushdown(p);
		int ans=0;
		if(ql<=mid){
			int ret=find_mxd(lc,ql,qr,l,mid);
			if(dep[ret]>dep[ans]) ans=ret;
		}
		if(qr>mid){
			int ret=find_mxd(rc,ql,qr,mid+1,r);
			if(dep[ret]>dep[ans]) ans=ret;
		}
		pushup(p);
		return ans;
	}
	inline ll query_sum(int p,int x,int l=1,int r=n){
		if(l==r) return sum[p];
		pushdown(p);
		if(x<=mid) return query_sum(lc,x,l,mid);
		else return query_sum(rc,x,mid+1,r);
	}
	#undef lc
	#undef rc
	#undef mid
}
inline int getup(int u,int d){
	//find u's d-ancestor
	for(int i=0;(1<<i)<=d;++i)
		if(d&(1<<i)) u=pa[u][i];
	return u;
}
inline void dfs_init(int u,int f){
	//init 
	fa[u]=f;dep[u]=dep[f]+1;
	pa[u][0]=f;
	for(int i=1;(1<<i)<=dep[u];++i)
		pa[u][i]=pa[pa[u][i-1]][i-1];
	//prepare multiply for findroot
	siz[u]=1;sval[u]=c[u];
	for(int v:to[u]){
		if(v==f) continue;
		dfs_init(v,u);
		siz[u]+=siz[v];sval[u]+=sval[v];
		if(siz[v]>siz[hson[u]])
			hson[u]=v;
	}
}
inline void hld(int u,int tp){
	//prepare for hld
	top[u]=tp;dfn[++tot]=u;pos[u]=tot;
	if(hson[u]) hld(hson[u],tp);
	for(int v:to[u])
		if(v!=fa[u]&&v!=hson[u])
			hld(v,v);
	ed[u]=tot;
}
inline int findrt(){
	//findrt:find the first element with prefix>sum/2,root must be its ancestor.
	//choose the deepst ancestor with sum>all/2 
	//maybe multiple roots,but anyone is OK in this problem
	int mid=SGT1::find(1,SGT1::sum[1]/2);
	// cout<<SGT1::sum[1]<<" "<<mid<<" "<<pos[mid]<<" "<<dfn[1]<<" "<<dfn[2]<<" "<<SGT1::query_sum(1,1,pos[mid]-1)<<endl;
	for(int i=19;i>=0;--i){
		int nxt=pa[mid][i];
		if(!nxt) continue;
		//in the first findrt,SGT2 isn't build,so we must use SGT1.This is just caused by the terrible implemention.
		if(SGT1::query_sum(1,pos[nxt],ed[nxt])<=SGT1::sum[1]/2) mid=nxt;
	}
	if(SGT1::query_sum(1,pos[mid],ed[mid])<=SGT1::sum[1]/2)
		mid=fa[mid];
	// cout<<"findrt"<<mid<<" "<<pos[mid]<<" "<<SGT1::query_sum(1,pos[mid],ed[mid])<<endl;
	return mid;
}
inline void change_val(int x,ll v){
	ll cge=v-c[x];
	c[x]=v;
	//first update the sum in the original tree;
	int u=x;
	SGT1::update(1,pos[u]);
	while(u){
		SGT2::add_sum(1,pos[top[u]],pos[u],cge);
		u=fa[top[u]];
	}
	//then update the root
	int nrt=findrt();
	if(rt==nrt) return;
	u=rt;
	while(u){
		SGT2::cover(1,pos[top[u]],pos[u],1);
		u=fa[top[u]];		
	}
	u=nrt;
	while(u){
		SGT2::cover(1,pos[top[u]],pos[u],0);
		u=fa[top[u]];		
	}
	rt=nrt;
}
inline ll query_ans(){
	// cout<<"query"<<rt<<" "<<pd[rt]<<endl;
	//rt itself
	if(pd[rt]){
		return max(SGT2::mxsum1[1],SGT1::sum[1]-SGT2::query_sum(1,pos[rt]));
	}
	//not rt's ancestor
	ll ans=SGT1::sum[1]-SGT2::ans1[1];
	// cout<<SGT1::sum[1]<<" "<<SGT2::ans1[1]<<" "<<ans<<endl;
	//rt's ancestor:find the deepest one
	int u=fa[rt],mx=0;
	while(u){
		int t=SGT2::find_mxd(1,pos[top[u]],pos[u]);
		if(dep[t]>dep[mx]) mx=t;
		u=fa[top[u]];
	}
	if(mx!=0) ans=min(ans,SGT2::query_sum(1,pos[getup(rt,dep[rt]-dep[mx]-1)]));
	// cout<<mx<<" "<<ans<<endl;
	return ans;
}
int main(){
//	freopen("data/miracle9.in","r",stdin);
//	freopen("data/miracle9.out","w",stdout);
	scanf("%d%d%d",&id,&n,&q);
	for(int i=1;i<=n;++i)
		scanf("%d%d",&pd[i],&c[i]);
	for(int i=1,u,v;i<n;++i){
		scanf("%d%d",&u,&v);
		to[u].push_back(v);
		to[v].push_back(u);
	}
//	cerr<<"??"<<endl;
	dfs_init(1,0);
//	cerr<<"??"<<endl;
	hld(1,1);
	SGT1::build();
	rt=findrt();
	SGT2::build();
	while(q--){
		int op,x,v;
		scanf("%d",&op);
		if(op==1){
			scanf("%d",&x);
			assert(pd[x]==1);
			pd[x]=0;
			SGT2::update_pt(1,pos[x]);
		}
		else if(op==2){
			scanf("%d",&x);
			assert(pd[x]==0);
			pd[x]=1;
			SGT2::update_pt(1,pos[x]);
		}
		else if(op==3){
			scanf("%d%d",&x,&v);
			change_val(x,v);
		}
		else if(op==4){
			assert(SGT2::ans2[1]!=-1);
			printf("%lld\n",query_ans());
		}
	}
	return 0;
}

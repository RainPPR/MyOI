#include <cstdio>
#include <queue>
#include <ctime>
#include <unordered_map>
#include <algorithm>
using std::queue;
using std::pair;
using std::unordered_map;
const int MOD=998244353;
inline int mval(int x) { return x>=MOD?x-MOD:x; }
inline int fix(int x) { return mval(x+MOD); }
inline void inc(int &x, int a) { x=mval(x+a); }
inline void dec(int &x, int a) { x=fix(x-a); }
inline int qpow(int x, int p)
{ int ret=1; while(p) { if(p&1) ret=1ll*ret*x%MOD; p>>=1, x=1ll*x*x%MOD; } return ret; }


int A, B;
inline void exgcd(int a, int b, int &x, int &y)
{
	if(!b) { x=1, y=0; return; }
	exgcd(b, a%b, y, x), y-=(a/b)*x;
}
inline int inv(int a, int p)
{
	int x, y;
	exgcd(a, p, x, y);
	return (x%p+p)%p;
}
queue<pair<int, int> > q;
unordered_map<int, int> disa, disb;
int main()
{
	// freopen("in.in", "r", stdin);
	// freopen("out.out", "w", stdout);
	int iv=qpow(21, MOD-2), riv=inv(31, MOD-1);
	scanf("%d%d", &A, &B);
	q.push({A, 0}), q.push({B, 1});
	int ans=0x3f3f3f3f;
	while(!q.empty())
	{
		auto [x, d]=q.front();
		q.pop();
		int typ=(d&1), ad=(d&2);
		d>>=2;
		if((typ?disb:disa).count(x)&&(typ?disb:disa)[x]<=(d<<1|(ad>>1))) continue;
		if(d*2-1>=ans) break;
		if((typ?disa:disb).count(x))
		{
			int v=(typ?disa:disb)[x];
			ans=std::min(ans, d+(v>>1));
		}
		(typ?disb:disa)[x]=(d<<1)|(ad>>1);
		if(!typ)
		{
			q.push({mval(x+11), (d+1)<<2});
			q.push({1ll*x*21%MOD, (d+1)<<2});
			q.push({qpow(x, 31), (d+1)<<2});
		}
		else
		{
			q.push({fix(x-11), (d+1)<<2|1});
			q.push({1ll*x*iv%MOD, (d+1)<<2|1});
			q.push({qpow(x, riv), (d+1)<<2|1});
		}
	}
	printf("%d\n", ans);
	fprintf(stderr, "%d\n", clock());
	return 0;
}
#include <cstdio>
#include <algorithm>
const int N=1000005;

int n, cnt[N*2];
int main()
{
	scanf("%d", &n);
	for(int i=1, x; i<=n; ++i)
	{
		scanf("%d", &x);
		if(x<2*n+3) cnt[x/2]=1;
	}
	int t=0;
	while(cnt[t]) ++t;
	printf("%d\n", t);
	return 0;
}
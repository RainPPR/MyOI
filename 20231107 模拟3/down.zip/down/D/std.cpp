#include <cstdio>
#include <vector>
#include <ctime>
#include <cstring>
#include <algorithm>
#define ll long long
#define ull unsigned long long
using std::vector;
typedef vector<int> poly;
const int N=10005, MOD=1000000007;
inline int mval(int x) { return x>=MOD?x-MOD:x; }
inline int fix(int x) { return mval(x+MOD); }
inline void inc(int &x, int a) { x=mval(x+a); }
inline void dec(int &x, int a) { x=fix(x-a); }
inline int qpow(int x, int p)
{ int ret=1; while(p) { if(p&1) ret=1ll*ret*x%MOD; p>>=1, x=1ll*x*x%MOD; } return ret; }
 
int iv[N], iiv[N], fac[N], tp;
namespace iobuff{
	const int LEN=1000000;
	char in[LEN+5], out[LEN+5];
	char *pin=in, *pout=out, *ed=in, *eout=out+LEN;
	inline char gc(void)
	{
		return pin==ed&&(ed=(pin=in)+fread(in, 1, LEN, stdin), ed==in)?EOF:*pin++;
	}
	inline void pc(char c)
	{
		pout==eout&&(fwrite(out, 1, LEN, stdout), pout=out);
		(*pout++)=c;
	}
	inline void flush()
	{ fwrite(out, 1, pout-out, stdout), pout=out; }
	template<typename T> inline void scan(T &x)
	{
		static int f;
		static char c;
		c=gc(), f=1, x=0;
		while(c<'0'||c>'9') f=(c=='-'?-1:1), c=gc();
		while(c>='0'&&c<='9') x=10*x+c-'0', c=gc();
		x*=f;
	}
	template<typename T> inline void putint(T x, char div)
	{
		static char s[15];
		static int top;
		top=0;
		x<0?pc('-'), x=-x:0;
		while(x) s[top++]=x%10, x/=10;
		!top?pc('0'), 0:0;
		while(top--) pc(s[top]+'0');
		pc(div);
	}
}
using namespace iobuff;
inline void init(void) { tp=2; iv[0]=iv[1]=iiv[0]=iiv[1]=1, fac[0]=fac[1]=1; }
inline void ext(int x)
{
	for(; tp<=x; ++tp)
	{
		iv[tp]=MOD-1ll*(MOD/tp)*iv[MOD%tp]%MOD;
		iiv[tp]=1ll*iiv[tp-1]*iv[tp]%MOD;
		fac[tp]=1ll*fac[tp-1]*tp%MOD;
	}
}
int n, q, t;
ll lt;
inline void conv(int &x, int &y, int &z)
{
	int c=x+y-z, b=x-y+z, a=y+z-x;
	x=a, y=b, z=c;
}
poly mul(const poly &a, const poly &b)
{
	int n=a.size()-1, m=b.size()-1;
	poly ret(n+m+1);
	static ull h[N];
	std::fill(h, h+n+m+1, 0);
	for(int i=0; i<=n; ++i)
	{
		for(int j=0; j<=m; ++j) h[i+j]+=1ull*a[i]*b[j];
		if((i&15)==15) for(int j=0; j<=m; ++j) h[i+j]%=MOD;
	}
	for(int i=0; i<=n+m; ++i) ret[i]=h[i]%MOD;
	return ret;
}
poly solve(ll l)
{
	if(l==1) return {1, 1, 1};
	poly ret=solve(l>>1);
	ret=mul(ret, ret);
	for(int i=n; i<ret.size(); ++i) inc(ret[i-n], ret[i]);
	if(ret.size()>n) ret.resize(n);
	if(l&1)
	{
		ret.push_back(0);
		ret.push_back(0);
		for(int i=ret.size()-1; i; --i) inc(ret[i], mval(ret[i-1]+(i>1?ret[i-2]:0)));
		if(ret.size()>n+1) inc(ret[1], ret[n+1]), ret.pop_back();
		if(ret.size()>n) inc(ret[0], ret[n]), ret.pop_back();
	}
	// printf("l %d %d %d\n", l, ret.size(), n);
	return ret;
}
poly f;
inline int reg(int x) { return (x%n+n)%n; }
inline int calc(int x, int x1)
{
	// printf("fa %d %d\n", f[reg(x1-x+lt)], f[reg(-x-x1+lt)]);
	return fix(f[reg(x1-x+t)]-f[reg(-x-x1+t)]);
}
inline int C(int n, int m) { return 1ll*fac[n]*iiv[m]%MOD*iiv[n-m]%MOD; }
int main()
{
	// freopen("in.in", "r", stdin);
	// freopen("out.out", "w", stdout);
	scanf("%d%lld%d", &n, &lt, &q);
	n+=2;
	int rn=n;
	// --n;
	n*=2;
	init();
	f=solve(lt);
	t=lt%n;
	// printf("%d\n", t);
	f.resize(n);
	// print(f);
	for(int i=1, x, y, x1, y1; i<=q; ++i)
	{
		scan(x), scan(y), scan(x1), scan(y1);
		++x, ++y, ++x1, ++y1;
		putint(1ll*calc(x, x1)*calc(y, y1)%MOD, '\n');
	}
	flush();
	fprintf(stderr, "time : %d\n", clock());
	return 0;
}
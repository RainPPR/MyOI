#include <cstdio>
#include <ctime>
#include <algorithm>
const int N=500005, MOD=1000000007;
inline int mval(int x) { return x>=MOD?x-MOD:x; }
inline int fix(int x) { return mval(x+MOD); }
inline void inc(int &x, int a) { x=mval(x+a); }
inline void dec(int &x, int a) { x=fix(x-a); }
inline int qpow(int x, int p)
{ int ret=1; while(p) { if(p&1) ret=1ll*ret*x%MOD; p>>=1, x=1ll*x*x%MOD; } return ret; }

int fac[N], inv[N];
inline void init(int n)
{
	fac[0]=1;
	for(int i=1; i<=n; ++i) fac[i]=1ll*i*fac[i-1]%MOD;
	inv[n]=qpow(fac[n], MOD-2);
	for(int i=n-1; ~i; --i) inv[i]=1ll*(i+1)*inv[i+1]%MOD;
}
inline int C(int n, int m) { return 1ll*fac[n]*inv[m]%MOD*inv[n-m]%MOD; }

int n, mx, k, cnt[N], mu[N], p[N], top;
int main()
{
	// freopen("in.in", "r", stdin);
	// freopen("out.out", "w", stdout);
	scanf("%d%d", &n, &k);
	mx=k;
	for(int i=1, x; i<=n; ++i) scanf("%d", &x), ++cnt[x], mx=std::max(mx, x);
	init(n);
	mu[1]=1;
	for(int i=1; i<=mx; ++i) for(int j=2*i; j<=mx; j+=i) cnt[i]+=cnt[j], mu[j]-=mu[i];
	int ans=0;
	for(int s=1; s<=std::min(n, k); ++s) if(k%s==0)
	{
		int d=k/s;
		int res=0;
		for(int i=1; i*d<=mx; ++i) if(mu[i]&&cnt[d*i]>=s)
			(mu[i]>0?inc:dec)(res, C(cnt[d*i], s));
		inc(ans, res);
	}
	printf("%d\n", ans);
	fprintf(stderr, "%d\n", clock());
	return 0;
}
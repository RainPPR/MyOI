#include<bits/stdc++.h>
#define V __p.first
#define W __p.second
#define go const auto &__p
#define all(x) x.begin(),x.end()
#define rep(i,x,y) for(int i = (x) ; i <= (y) ; ++ i)
using namespace std ;
using ll = long long ;
const int N = 2.5e5 + 20 ;
const int Lg = 18 ;
const int Hflg = 8 ;
const int Sqr = (1 << Hflg) + 2 ;
int n ; 
int m ;
int a[N] ;
using ifo = pair<int,ll> ;
ifo s[Hflg + 1][N] ;
inline void maintain (ifo a,ifo b,ifo &c){
    c = {max(a.first , b.first) , a.second + b.second} ;
    c.second += c.first ;
}
inline void change (int p,int v) {
    s[0][p] = {v,v} ;
    rep(i,1,Hflg) {
        rep(j,max(1,p - (1 << i) + 1),p) {
            maintain(s[i-1][j],s[i-1][j+(1<<(i-1))],s[i][j]);
        }
    }
}
int sta[Sqr] , lev[Sqr] , top ;
ll qry(int k , int x) {
    if(k <= Hflg) return s[k][x].second ;
    ll res = 0 ;
    top = 0; 
    for(int i = x ; i <= x + (1 << (k)) - 1; i += (1 << Hflg)) {
        res += s[Hflg][i].second ;
        sta[ ++ top ] = s[Hflg][i].first , lev[top] = 0 ;
        while(top > 1 && lev[top] == lev[top - 1]) {
            -- top ;
            lev[top] ++ ;
            sta[top] = max(sta[top],sta[top + 1]);
            res += sta[top] ;
        }
    }
    return res; 
}

signed main ( ) {
    ios::sync_with_stdio(false) ;
    cin.tie(0),cout.tie(0) ;
    cin >> n >> m ;
    rep(i,1,n) cin >> a[i] , s[0][i] ={a[i],a[i]} , assert(a[i] <= 1e9) ;
    rep(i,1,Hflg) {
        rep(j,1,n - (1 << i) + 1) {
            maintain(s[i-1][j],s[i-1][j+(1<<(i-1))],s[i][j]);
        }
    }
    int op , l , r , x , p , k;
    while(m --) {
        cin >> op ;
        if(op == 0) {
            cin >> l >> r; 
            k = __lg(r - l + 1) ;
            assert((1 << k) == (r - l + 1)) ;
            assert(r <= n) ;
            assert(l <= r) ;
            cout << qry(k , l) << '\n' ;
        }
        else {
            cin >> p >> x ;
            assert(1 <= p) , 
            assert(p <= n) , 
            assert(x <= 1e9) ,
            change(p , x) ; 
        }
    }
}
#include<bits/stdc++.h>
using namespace std;
const int N=10;
const int M=100005;
int cnt[N],dp[1<<N|5][1<<N|5],a[M],n;
bool chk(int s,int t,int x)
{
	for(int i=0;i<9;++i)for(int j=i+1;j<9;++j)if((s&(1<<i))&&(s&(1<<j))&&(i+j+x)%9==0)return 0;
	for(int i=0;i<9;++i)if((t&(1<<i))&&(2*i+x)%9==0)return 0;
	return 1;
}
int main()
{
	scanf("%d",&n);int ans=0;
	for(int i=1;i<=n;++i)scanf("%d",&a[i]);
	for(int i=1;i<=n;++i)++cnt[a[i]%9];
	for(int s=0;s<(1<<9);++s)
	{
		for(int t=s;t>=0;t=(t-1)&s)
		{
			ans=max(dp[s][t],ans);
			for(int i=0;i<9;++i)if(!(s&(1<<i))&&cnt[i])
			{
				if(!chk(s,t,i))continue;
				dp[s|(1<<i)][t]=max(dp[s|(1<<i)][t],dp[s][t]+1);
				int x=(9-2*i%9)%9;if(cnt[i]<2||(s&(1<<x)))continue;
				if(i*3%9==0)dp[s|(1<<i)][t|(1<<i)]=max(dp[s|(1<<i)][t|(1<<i)],dp[s][t]+2);
				else dp[s|(1<<i)][t|(1<<i)]=max(dp[s|(1<<i)][t|(1<<i)],dp[s][t]+cnt[i]);
			}
			if(!t)break;
		}		
	}
	printf("%d",ans);
	return 0;
}
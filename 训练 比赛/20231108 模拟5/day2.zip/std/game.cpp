#include<bits/stdc++.h>
#define pii pair<int,int>
#define mp make_pair
using namespace std;
const int N=500005;int mod;
pii operator *(const pii &A,const int x)
{return mp(1ll*x*A.first%mod,1ll*x*A.second%mod);}
pii operator +(const pii &A,const pii &B)
{return mp((A.first+B.first)%mod,(A.second+B.second)%mod);}
pii operator -(const pii &A,const pii &B)
{return mp((A.first-B.first+mod)%mod,(A.second-B.second+mod)%mod);}
int ksm(int a,int k)
{
	int ret=1;
	while(k)
	{
		if(k&1)ret=1ll*ret*a%mod;
		a=1ll*a*a%mod;k>>=1;
	}
	return ret;
}
int n,p2[N],ans,inv2[N];pii dp[N];
int main()
{
	scanf("%d%d",&n,&mod);
	if(n==1)return printf("1"),0;p2[0]=inv2[0]=1;
	for(int i=1;i<N;++i)p2[i]=2*p2[i-1]%mod;
	for(int i=1;i<N;++i)inv2[i]=1ll*(mod+1)/2*inv2[i-1]%mod;
	dp[1]=mp(1,0);dp[2]=mp(2,mod-2);
	for(int i=3;i<=2*n-1;++i)
	{
		int base=4,nw=2;dp[i]=mp(0,-2);
		dp[i]=dp[i]+dp[i-1]*(3ll*inv2[1]%mod);
		while(i-base+1>1)
		{
			dp[i]=dp[i]-(dp[i-base+1]+mp(0,nw+1))*inv2[nw];
			base*=2;++nw;
		}
		dp[i]=dp[i]-mp(0,nw)*inv2[nw-1];
	}
	pii tmp=mp(0,1);
	int base=4,nw=2;while(2*n-base+1>1)
	{
		tmp=tmp+(dp[2*n-base+1]+mp(0,nw+1))*inv2[nw+1];
		++nw;base*=2;
	}
	tmp.second=(tmp.second+1ll*nw*inv2[nw])%mod;tmp=tmp*4*ksm(3,mod-2);
	ans=1ll*(tmp.second-dp[2*n-1].second+mod)*ksm(dp[2*n-1].first-tmp.first+mod,mod-2)%mod;
	printf("%lld",((1ll*dp[n].first*ans+dp[n].second)%mod+mod)%mod);
	return 0;
}
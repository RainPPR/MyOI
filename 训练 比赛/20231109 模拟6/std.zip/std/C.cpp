#include<bits/stdc++.h>
using namespace std;

#define rep(i,a,b) for(int i=(a),i##end=(b);i<=i##end;++i)
#define per(i,a,b) for(int i=(a),i##end=(b);i>=i##end;--i)
template<typename T>void chkmax(T&x,const T&y){if(x<y)x=y;}
template<typename T>void chkmin(T&x,const T&y){if(y<x)x=y;}

#define pb push_back

typedef long long ll;
typedef vector<int>vi;
typedef pair<int,int>pii;

const int maxn=1e5+10,inf=INT_MAX;

int n,m;
vector<pii>G[maxn];

vi nod;
int cir,dis[maxn];
void dfs(int u){
  nod.pb(u);
  for(auto[v,w]:G[u]){
    if(dis[v]==inf){
      dis[v]=dis[u]+w,dfs(v);
    }else{
      cir=__gcd(cir,abs(dis[u]-dis[v]+w));
    }
  }
}

int f[maxn];
int dp(int u){
  if(~f[u])return f[u];
  f[u]=0;
  for(auto[v,w]:G[u])if(w==1){
    chkmax(f[u],dp(v)+1);
  }
  return f[u];
}

int main(){
  cin>>n>>m;
  assert(m);
  rep(i,1,m){
    int u,v;
    cin>>u>>v;
    G[u].pb({v,1});
    G[v].pb({u,-1});
  }
  
  vector<vi>all;
  rep(i,1,n)dis[i]=inf;
  rep(i,1,n)if(dis[i]==inf){
    nod.clear();
    dis[i]=0,dfs(i);
    all.pb(nod);
  }
  
  if(cir){
    cout<<n-cir<<endl;
    return 0;
  }
  
  memset(f,-1,sizeof f);
  int res=0;
  for(vi v:all){
    int cur=0;
    for(int u:v)if(f[u]==-1){
      chkmax(cur,dp(u));
    }
    res+=cur;
  }
  cout<<n-res<<endl;
  return 0;
}

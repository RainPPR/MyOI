#include <bits/stdc++.h>
using namespace std;

#define rep(i,a,b) for(int i=(a),i##end=(b);i<=i##end;++i)
#define per(i,a,b) for(int i=(a),i##end=(b);i>=i##end;--i)
template<typename T>void chkmax(T&x,T y){if(x<y)x=y;}
template<typename T>void chkmin(T&x,T y){if(x>y)x=y;}

typedef long long ll;
typedef vector<int>vi;

const int N=1e5+10;

int n;
char S[N];
//string str;

int pre1[N],nxt1[N];

#define len(x,y) max(0,(y)-nxt1[x]+1)

//short lcp[2555][2555];

int lst_len;

namespace SA{
  static const int maxn=N*3;
  char A[maxn];
  int m,sa[maxn],rk[maxn],ht[maxn],tp[maxn],bf[maxn],buk[maxn];
  void radix_sort(){
    memset(buk,0,(m+1)<<2);
    rep(i,1,n)buk[bf[i]=rk[tp[i]]]++;
    rep(i,1,m)buk[i]+=buk[i-1];
    per(i,n,1)sa[buk[bf[i]]--]=tp[i];
  }
  int lg[maxn],st[20][maxn];
  void build(){
    m=150;
    rep(i,1,n)rk[i]=A[i],tp[i]=i;
    radix_sort();
    for(int k=1;k<=n;k<<=1){
      int num=0;
      per(i,n,n-k+1)tp[++num]=i;
      rep(i,1,n)if(sa[i]>k)tp[++num]=sa[i]-k;
      radix_sort();
      swap(rk,tp),rk[sa[1]]=1,num=1;
      rep(i,2,n)rk[sa[i]]=num+=tp[sa[i]]!=tp[sa[i-1]]||tp[sa[i]+k]!=tp[sa[i-1]+k];
      if(n==num)break;
      m=num;
    }
    for(int i=1,j=0;i<=n;i++){
      if(j)j--;
      while(A[i+j]==A[sa[rk[i]-1]+j])j++;
      ht[rk[i]]=j;
    }
    rep(i,2,n)lg[i]=lg[i>>1]+1;
    rep(i,1,n)st[0][i]=ht[i];
    rep(i,1,lg[n])rep(j,1,n-(1<<i)+1)st[i][j]=min(st[i-1][j],st[i-1][j+(1<<(i-1))]);
  }
  int query(int l,int r){
    int k=lg[r-l+1];
    return min(st[k][l],st[k][r-(1<<k)+1]);
  }
  int lcp(int i,int j){
    if(i==j)return n-i+1;
    i=rk[i],j=rk[j];
    if(i>j)swap(i,j);
    return query(i+1,j);
  }
}

bool leq(int l1,int r1,int l2,int r2){
  int x=len(l1,r1),y=len(l2,r2);
  if(x!=y)return x<y;
  l1+=r1-l1+1-x;
  l2+=r2-l2+1-y;
  int tp=SA::lcp(l1,l2);
//  printf("(%d %d) %d\n",l1,l2,tp);
//  int tp=lcp[l1][l2];
  return l1+tp<=r1&&S[l1+tp]<S[l2+tp];
}

int main(){
  scanf("%s",S+1);
  n=strlen(S+1);
  
  memcpy(SA::A,S,sizeof S);
  SA::build();
//  per(i,n,1)per(j,n,1)lcp[i][j]=S[i]==S[j]?lcp[i+1][j+1]+1:0;
  nxt1[n+1]=n+1;
  per(i,n,1)nxt1[i]=S[i]==48?nxt1[i+1]:i;
  pre1[0]=0;
  rep(i,1,n)pre1[i]=S[i]==48?pre1[i-1]:i;
  static int dp[N];
  {
    rep(i,1,n)dp[i]=1;
    rep(i,1,n){
      chkmax(dp[i],dp[i-1]);
      int sz=max(1,len(dp[i],i));
      int gg=nxt1[i+1]+sz-1;
      if(gg<=n){
        if(leq(dp[i],i,i+1,gg))dp[gg]=i+1;
        else if(gg<n&&leq(dp[i],i,i+1,gg+1))dp[gg+1]=i+1;
      }
    }
//    rep(i,1,n){
//      chkmax(dp[i],dp[i-1]);
//      rep(j,i+1,n)if(leq(dp[i],i,i+1,j)){
//        dp[j]=i+1;break;
//      }
//    }
//    rep(i,2,n){
//      per(j,i-1,1)if(leq(dp[j],j,j+1,i)){
//        dp[i]=j+1;break;
//      }
//    }
    lst_len=n-dp[n]+1;
//    printf("#%d\n",lst_len);
    if(!lst_len){
      puts("1");
      int st=1;
      while(st<n&&S[st]=='0')st++;
      rep(i,st,n)putchar(S[i]);
    }
  } // dp1 : lst_len
  memset(dp,-1,sizeof dp);
  dp[n-lst_len+1]=n+1;
  per(i,n-lst_len,1){
    if(S[i]==48)dp[i]=n+1;
    else break;
  }
  int lst=n+1;
  per(i,n,2){
    if(dp[i]!=-1){
      int sz=len(i,dp[i]-1);
      int gg=max(1,i-sz);
      if(leq(gg,i-1,i,dp[i]-1))gg=pre1[gg-1]+1;
      else gg++;
      chkmin(lst,i-1);
      rep(j,gg,lst)chkmax(dp[j],i);
      chkmin(lst,gg-1);
//      rep(j,gg,i-1)chkmax(dp[j],i);
//      per(j,i-1,1)if(leq(j,i-1,i,dp[i]-1)){
//        chkmax(dp[j],i);
//      }
    }
  }
//  per(i,n-lst_len,1)if(dp[i]==-1){
//    per(j,n,i+1)if(dp[j]!=-1&&leq(i,j-1,j,dp[j]-1)){
//      dp[i]=j;break;
//    }
//  }
  int cur=1;
  vector<string>out;
  while(cur<=n){
//    cur,dp[cur]-1
//    printf("[%d %d]\n",lst,cur);
    int st=cur;
    while(st<dp[cur]-1&&S[st]=='0')st++;
    string s;
    rep(i,st,dp[cur]-1)s+=S[i];
    out.push_back(s);
    cur=dp[cur];
  }
  printf("%d\n",(int)out.size());
  for(string s:out)cout<<s<<' ';
  return 0;
}

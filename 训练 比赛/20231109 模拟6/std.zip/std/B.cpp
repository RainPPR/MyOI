#include<bits/stdc++.h>
using namespace std;

#define rep(i,a,b) for(int i=(a),i##end=(b);i<=i##end;++i)
#define per(i,a,b) for(int i=(a),i##end=(b);i>=i##end;--i)

typedef long long ll;
typedef vector<int>vi;

typedef unsigned u32;
typedef unsigned uint;
typedef unsigned long long u64;

typedef vector<vi>vvi;

vvi solve(string S,int P){
  int n=S.size();
  vvi F(n,vi(n,0));
  rep(i,0,n-1){
    F[i][i]=1;
  }
  rep(k,2,n){
    rep(l,0,n-k){
      int r=l+k-1;
      F[l][r]=F[l+1][r];
      if(S[l]=='('){
        rep(pos,l+1,r)if(S[pos]==')'){
          F[l][r]=(F[l][r]+1ll*(pos==l+1?1:F[l+1][pos-1])*F[pos][r])%P;
        }
      }
    }
  }
  return F;
}

int main(){
  string S;
  cin>>S;
  
  static const int P=998244353;
  vvi F=solve(S,P);
  vvi G=solve(S,1024);
  
  int n=S.size();
  long long ans=0;
  rep(l,0,n-1)rep(r,l,n-1){
    ans+=F[l][r];
    rep(b,0,9)if(((l+1)^(r+1))>>b&1){
      ans+=(G[l][r]>>b&1?-1:1)*(1<<b);
    }
    
//    printf("(%d %d) : %d\n",l+1,r+1,F[l][r]);
  }
  cout<<(ans%P+P)%P<<endl;
  return 0;
}

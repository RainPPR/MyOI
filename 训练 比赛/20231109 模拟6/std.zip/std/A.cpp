#include<bits/stdc++.h>
using namespace std;

#define rep(i,a,b) for(int i=(a),i##end=(b);i<=i##end;++i)
#define per(i,a,b) for(int i=(a),i##end=(b);i>=i##end;--i)

typedef vector<int>vi;

int main(){
  int n;
  cin>>n;
  vi a(n);
  for(int&x:a)cin>>x;
  
  rep(i,0,n-1)rep(j,i+1,n-1)if(a[i]==a[j]){
    puts("1 1");
    printf("%d\n%d\n",i+1,j+1);
    return 0;
  }
  puts("-1");
  return 0;
}

#include <iostream>
#include <cstdio>
#include <algorithm>
#include <set>
#include <map>
#include <cmath>
#include <cassert>
#include <queue>
using namespace std;

typedef long long ll;
typedef double db;
typedef pair <int,int> Pii;
#define pb push_back
#define mp make_pair
#define rep(i,a,b) for(int i = a, i##end = b; i <= i##end; ++i)
#define drep(i,a,b) for(int i = a, i##end = b; i >= i##end; --i)
template <class T> inline void cmin(T &a, T b){ ((a > b) && (a = b)); }
template <class T> inline void cmax(T &a, T b){ ((a < b) && (a = b)); }
template <class T = int> T rd() {
    T s = 0; int f = 0; char c;
    while(c = getchar(), c < 48) f = c == '-';
    do s = (s << 1) + (s << 3) + (c - 48);
    while(c = getchar(), c > 47);
    return f ? -s : s;
}

const int N = 1e6 + 10, INF = 1e9 + 10, P = 1e9 + 7;

int n, F[N], J[N];
struct BIT {
    int s[N];
    void add(int p, int x) {
        while(p <= n) s[p] += x, p += p & -p;
    }
    int query(int p) {
        int res=0;
        while(p) res += s[p], p -= p & -p;
        return res;
    }
} T;

int C2(int n) {
    if(n <= 1) return 0;
    return 1ll * n * (n - 1) / 2 % P;
}

int count(int *a){
    int c=0;
    rep(i,1,n) rep(j,i+1,n) c += a[i] > a[j];
    return c;
}

int nxt_perm(int *a) {
    static int b[N], I[N];
    rep(i,1,n) b[i] = a[i];
    next_permutation(b + 1, b + n + 1);
    rep(i,1,n) rep(j,1,n) if(b[j] == a[i]) I[i] = j;
    rep(i,1,n) a[i] = b[i];
    return count(I);
}

int brute() {
    static int a[N],b[N];
    rep(i,1,n) a[i]=rd(),b[i]=i;
    int ans =0 ;
    while(1) {
        int f= 0;
        rep(i,1,n) f |= a[i] != b[i];
        if(!f) break;
        ans += nxt_perm(b);
    }
    return  ans;

}

int main() {
    // freopen("perm.in", "r", stdin), freopen("perm.out", "w", stdout);
    n = rd();
    // printf("%d\n",brute()); return 0;
    F[1] = 0;
    rep(i,2,n)
        F[i] = (1ll * i * F[i-1] % P + 1ll * (C2(i - 2) + i - 1) % P * (i - 1)) % P;
    rep(i,*J=1,n) J[i] = 1ll * J[i-1] * i % P;
    // rep(i,1,n) printf("%d ", F[i]);
    int turn = 0, ans = 0;
    rep(i,1,n) {
        int x = rd();
        int c = x - 1 - T.query(x);
        T.add(x, 1);
        turn = (turn + 1ll * c * J[n - i]) % P;
        ans = (ans + 1ll * (F[n-i] + C2(n - i - 1) + n - i) * c) % P;
    }
    printf("%d %d\n", turn, ans);
}


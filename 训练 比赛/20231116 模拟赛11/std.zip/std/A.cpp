#include <cstdio>
#include <cassert>

const int N = 1010;

bool Mbe;
int n, m, col[N];
int ls[N], rs[N], a[N], c, siz[N];

struct List {
	const List *l, *r;
	int v;
	List() = delete;
	List(const List *l, const List *r, int v): l(l), r(r), v(v) { }
};

struct Dfs {
	const List* stk[N];
	int top;
	void init(const List *u) {
		stk[top = 1] = u;
		while(stk[top] -> l) {
			const List *t = stk[top] -> l;
			stk[++top] = t;
		}
	}
	void next() {
		while(top && (top == 1 || stk[top] == stk[top - 1] -> r)) top--;
		if(top) {
			stk[top] = stk[top - 1] -> r;
			while(stk[top] -> l) {
				const List *t = stk[top] -> l;
				stk[++top] = t;
			}
		}
	}
	int v() {
		return top ? stk[top] -> v : 0;
	}
} X, Y;

const List* dp[N][N];
const List* conn(const List *a,const List *b) {
	if(a == NULL) return NULL;
	if(b == NULL) return NULL;
	return new List(a, b, -1);
}
const List* min(const List *a, const List *b) {
	if(a == NULL) return b;
	if(b == NULL) return a;
	X.init(a), Y.init(b);
	while(X.v() && X.v() == Y.v()) X.next(), Y.next();
	return X.v() < Y.v() ? a : b;
}

void show(const List *a) {
	X.init(a);
	while(X.v()) printf("%d ",X.v()), X.next();
	puts("");
}

void dfs(int u) {
	if(!ls[u]) {
		dp[u][0] = new List(NULL, NULL, a[u]);
		return;
	}
	dfs(ls[u]), dfs(rs[u]);
	siz[u] = siz[ls[u]] + siz[rs[u]] + col[u];
	for(int i = 0; i <= siz[ls[u]]; ++i) {
		for(int j = 0; j <= siz[rs[u]]; ++j) {
			dp[u][i + j] = min(dp[u][i + j], conn(dp[ls[u]][i], dp[rs[u]][j]));
			if(col[u]) dp[u][i + j + 1] = min(dp[u][i + j + 1], conn(dp[rs[u]][j], dp[ls[u]][i]));
		}
	}
	/*for(int i = 0; i <= siz[u]; ++i) {
		if(dp[u][i] != NULL) {
			printf("#(%d, %d): ", u, i);
			show(dp[u][i]);
		}
	}*/
}

void dfs(const List *u) {
	if(u -> l) {
		dfs(u -> l);
		dfs(u -> r);
	} else printf("%d ", u -> v);
}

bool Med;
int main() {
	fprintf(stderr, "%.2lf\n", (&Med - &Mbe) / 1024. /1024.);
	// freopen("binary.in", "r", stdin); freopen("binary.out", "w", stdout);
	scanf("%d%d", &n, &m);
	assert(1 <= n && n <= 1000 && (n & 1));
	assert(0 <= m && m <= (n - 1) / 2);
	for(int i = 1, t; i <= n; ++i) {
		scanf("%d%d", col + i, &t);
		assert(0 <= col[i]  && col[i] <= 1);
		if(t == 1) {
			scanf("%d%d", ls + i, rs + i);
			assert(i < ls[i] && ls[i] <= n);
			assert(i < rs[i] && rs[i] <= n);
		} else {
			scanf("%d", a + i);
			assert(1 <= a[i] && a[i] <= 1e9);
		}
	}
	dfs(1);
	if(siz[1] == 0 && m > 0) {
		puts("-1");
		fprintf(stderr, "%d\n", -1);
		return 0;
	}
	const List *ans = NULL;
	for(int i = m; i >= 0; i -= 2) ans = min(ans, dp[1][i]);
	assert(ans != NULL), show(ans);
}


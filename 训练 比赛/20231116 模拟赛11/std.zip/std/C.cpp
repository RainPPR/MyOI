#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
#include <cassert>
using namespace std;

typedef pair <int,int> Pii;
#define pb push_back
#define rep(i,a,b) for(int i=a,i##end=b;i<=i##end;++i)
#define drep(i,a,b) for(int i=a,i##end=b;i>=i##end;--i)
template <class T> inline void cmin(T &a,T b){ ((a>b)&&(a=b)); }
template <class T> inline void cmax(T &a,T b){ ((a<b)&&(a=b)); }

char IO;
int rd() {
	int s = 0; char c;
	while(c = getchar(), c < 48);
	do s = s * 10 + c - 48;
	while(c = getchar(), c > 47);
	return s;
}

const int N = 4e5 + 10, M = N * 32, INF = 1 << 30;

int n, a[N];
int nxt[M][2], cnt, c[M];
int ans;

void add(int x, int k) {
	int u = 1; c[u] += k;
	drep(i,29,0) {
		int &v = nxt[u][(x >> i) & 1];
		if(!v) v = ++cnt;
		c[u = v] += k;
	}
}

int query(int u,int d,int x) {
	if(d < 0) return 0;
	int c = (x >> d) & 1;
	if(nxt[u][c]) return query(nxt[u][c], d - 1, x);
	else return query(nxt[u][!c], d - 1, x) + (1 << d);
}

vector <int> get(int u, int d, int val) {
	vector <int> res;
	auto dfs = [&](auto &&self, int u, int d, int val) -> void {
		if(d == -1) {
			rep(i,1,c[u]) res.pb(val);
			return;
		}
		if(nxt[u][0]) self(self, nxt[u][0], d - 1, val);
		if(nxt[u][1]) self(self, nxt[u][1], d - 1, val | (1 << d));
	};
	dfs(dfs, u, d, val);
	return res;
}

int dfs1(int u, int d) {
	if(!u) return 0;
	if(~c[nxt[u][0]] & 1) return max(dfs1(nxt[u][0], d - 1), dfs1(nxt[u][1],d - 1));
	int res = INF;
	for(int i: get(nxt[u][0], d - 1, 0)) cmin(res, query(nxt[u][1],d - 1, i));
	return res + (1 << d);
}

vector <Pii> dfs(int u, int d, int val) {
	assert(c[u] & 1);
	// cout << "dfs1 " << u << ' ' << d << ' ' << val << endl;
	if(d == -1) return {make_pair(val, 0)};
	int p = c[nxt[u][1]] & 1;
	auto l = dfs(nxt[u][p], d - 1, val | (p << d));
	int r = dfs1(nxt[u][!p], d - 1);
	for(auto &[x, y]: l) cmax(y, r);
	if(nxt[u][!p]) {
		vector <Pii> v;
		int m1 = INF, m2 = INF;
		for(int i: get(nxt[u][!p], d - 1, val | ((!p) << d))) {
			int q =  query(nxt[u][p], d - 1, i) | (1 << d);
			if(q < m1) m2 = m1, m1 = q;
			else cmin(m2, q);
			v.push_back(make_pair(i, q));
		}
		for(auto [x, y]: v) l.pb(make_pair(x, y == m1 ? m2 : m1)) ;
	}
	return l;
}

int main(){
	// freopen("xor.in", "r", stdin), freopen("xor.out", "w", stdout);
	n = rd(), cnt = 1;
	rep(i,1,n*2+1) add(a[i] = rd(), 1);
	auto res = dfs(1, 29, 0);
	sort(res.begin(), res.end());
	// for(auto [x, y]: res) printf("%d %d\n", x, y);
	rep(i,1,n*2+1) 
		printf("%d%c",
				lower_bound(res.begin(), res.end(), make_pair(a[i], 0)) -> second,
				" \n"[i == iend]);
}





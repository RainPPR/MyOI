#include <cstdio>
#include <cassert>
#include <algorithm>
using ll = long long;

const int N = 1e6 + 10, M = 2 * N;

char buf[200000], *p1, *p2;
#define getchar() (((p1 == p2) && (p2 = (p1 = buf) + fread(buf, 1, 200000, stdin))), *p1++)
int rd() {
	int s = 0; char c;
	while(c = getchar(), c < 48);
	do s = (s << 1) + (s << 3) + (c - 48);
	while(c = getchar(), c > 47);
	return s;
}

int n, m;
int a[N], stk[N], top;
int fa[N], dep[N], R[N];

struct LCA {
	int s[20][N], Log[N];
	int dmin(int x, int y) {
		return dep[x] < dep[y] ? x : y;
	}
	void init() {
		for(int i = 1; i <= n; ++i) s[0][i] = i;
		for(int i = 2; i <= n; ++i) Log[i] = Log[i >> 1] + 1;
		for(int i = 1; i <= Log[n]; ++i) {
			for(int j = 1, L = 1 << (i - 1); j <= n - L; ++j) s[i][j] = dmin(s[i - 1][j], s[i - 1][j + L]);
		}
	}
	int operator () (const int x, const int y) {
		// assert(x <= y);
		if(R[x] >= y) return x;
		int d = Log[y - x + 1];
		return fa[dmin(s[d][x], s[d][y - (1 << d) + 1])];
	}
} lca;

struct Node {
	int o, x, y;
	bool operator < (const Node __) const {
		return x < __.x;
	}
} A[M], T[M];
int c;
ll ans[M];
ll f[N], g[N];
void pop(int u, int v) {
	f[u] += f[v], g[u] += 1ll * dep[u] * f[v];
	top--;
}
void push(int x) {
	g[x] += g[stk[top]];
	stk[++top] = x;
}
void ins(int x) {
	// printf("insert %d %lld %lld\n", x, f[x], g[x]);
	if(stk[top] == x) return;
	if(!top) { stk[++top] = x; return; }
	int y = lca(stk[top], x);
	// printf("lca = %d\n", y);
	if(y == stk[top]) return push(x);
	while(stk[top - 1] >= y) pop(stk[top - 1], stk[top]);
	if(stk[top] != y) {
		// puts("add lca");
		f[y] = 0, g[y] = g[stk[top - 1]];
		pop(y, stk[top]);
		stk[++top] = y;
	}
	push(x);
	// printf("inserted %lld %lld\n", f[x], g[x]);
}
void add(int x, int y) {
	f[x] += y, g[x] += 1ll * dep[x] * y;
	ins(x);
}
ll query(int x) {
	ins(x);
	return g[x];
}

void solve(int l, int r) {
	if(r - l <= 50) {
		for(int i = l; i <= r; ++i) if(A[i].o == 1) {
			for(int j = i + 1; j <= r; ++j) if(A[j].o == 2) {
				ans[A[j].y] += 1ll * dep[A[j].x <= A[i].x ? A[j].x : lca(A[i].x, A[j].x)] * A[i].y;
			}
		}
		std::sort(A + l, A + r + 1);
		return;
	}
	int mid = (l + r) >> 1;
	solve(l, mid), solve(mid + 1, r);
	int p1 = l, p2 = mid + 1, p3 = l;
	top = 0;
	ll s = 0;
	for(int i = l; i <= r; ++i) f[A[i].x] = g[A[i].x] = 0;
	for(int i = l; i <= mid; ++i) if(A[i].o == 1) s += A[i].y;
	// puts("----start-----");
	while(p1 <= mid || p2 <= r) {
		if(p1 <= mid && (p2 > r || A[p1] < A[p2])) {
			if(A[p1].o == 1) {
				// printf("add %d %d\n", A[p1].x, A[p1].y);
				add(A[p1].x, A[p1].y), s -= A[p1].y;
			}
			T[p3++] = A[p1++];
		} else {
			if(A[p2].o == 2) {
				ans[A[p2].y] += query(A[p2].x) + 1ll * dep[A[p2].x] * s;
				// printf("query %d %d %lld %lld\n", A[p2].y, A[p2].x, query(A[p2].x), 1ll * dep[A[p2].x] * s);
			}
			T[p3++] = A[p2++];
		}
	}
	for(int i = l; i <= r; ++i) A[i] = T[i];
}

int main() {
	// freopen("snow.in", "r", stdin), freopen("snow.out", "w", stdout);
	n = rd() + 1, m = rd();
	// fprintf(stderr, "%d %d\n", n, m);
	a[stk[top = 1] = 1] = 1e9 + 10, dep[1] = 1;
	for(int i = 2; i <= n; ++i) {
		a[i] = rd(), R[i] = i;
		// assert(1 <= a[i] && a[i] <= n);
		while(top && a[stk[top]] <= a[i]) R[stk[top - 1]] = R[stk[top]], top--;
		fa[i] = stk[top], stk[dep[i] = ++top] = i;
		// printf("edge %d %d %d\n", fa[i], i, dep[i]);
	}
	while(top) R[stk[top - 1]] = R[stk[top]], top--;
	lca.init(); int q = 0;
	for(int i = 1; i <= m; ++i) {
		int o = rd(), l = rd() + 1, r = rd() + 1;
		assert(l <= r);
		if(o == 1) {
			int x = rd();
			if(l > 1) A[++c] = (Node){1, l - 1, -x};
			A[++c] = (Node){1, r, x};
		} else {
			if(lca(l, r) != l) q += 2, ans[q] = -1;
			else {
				A[++c] = (Node){2, fa[l], ++q};
				A[++c] = (Node){2, r, ++q};
			}
		}
	}
	// ll min = 1e9, max = -1;
	solve(1, c);
	for(int i = 1; i <= q; i += 2) {
		// min = std::min(ans[i + 1] - ans[i], min);
		// max = std::max(ans[i + 1] - ans[i], max);
		printf("%lld\n", ans[i + 1] - ans[i]);
	}
	// fprintf(stderr, "%lld %lld\n", min, max);
	// assert(min >= -1 && min <= 1e9);
}


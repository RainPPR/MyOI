#include <bits/stdc++.h>
using namespace std;

#define pb push_back
const int N = 1e3 + 10, INF = 1e9 + 10;

int n, m, col[N];
int ls[N], rs[N], a[N], c, siz[N];

typedef vector <int> V;
void release(V &a) {
	V b;
	swap(a, b);
}
V concat(V a, const V &b) {
	for(int i:b) a.pb(i);
	return a;
}

V dp[N][N], T[N], vi=V{INF};
void dfs(int u) {
	if(!ls[u]) {
		dp[u][0] = V{a[u]};
		return;
	}
	dfs(ls[u]), dfs(rs[u]);
	siz[u] = siz[ls[u]] + siz[rs[u]] + col[u];
	for(int i = 0; i <= siz[u]; ++i) dp[u][i] = vi;
	for(int i = 0; i <= siz[ls[u]]; ++i) {
		for(int j = 0; j <= siz[rs[u]]; ++j) {
			dp[u][i + j] = min(dp[u][i + j], concat(dp[ls[u]][i], dp[rs[u]][j]));
			if(col[u]) dp[u][i + j + 1] = min(dp[u][i + j + 1], concat(dp[rs[u]][j], dp[ls[u]][i]));
		}
	}
	for(int i = 0; i <= siz[ls[u]]; ++i) release(dp[ls[u]][i]);
	for(int i = 0; i <= siz[rs[u]]; ++i) release(dp[rs[u]][i]);
}

int main() {
	freopen("binary.in", "r", stdin); freopen("binary.out", "w", stdout);
	scanf("%d%d", &n, &m);
	assert(1 <= n && n <= 1000 && (n & 1));
	assert(0 <= m && m <= (n - 1) / 2);
	for(int i = 1, t; i <= n; ++i) {
		scanf("%d%d", col + i, &t);
		assert(0 <= col[i]  && col[i] <= 1);
		if(t == 1) {
			scanf("%d%d", ls + i, rs + i);
			assert(i < ls[i] && ls[i] <= n);
			assert(i < rs[i] && rs[i] <= n);
		} else {
			scanf("%d", a + i);
			assert(1 <= a[i] && a[i] <= 1e9);
		}
	}
	dfs(1);
	if(siz[1] == 0 && m > 0) {
		puts("-1");
		fprintf(stderr, "%d\n", -1);
		return 0;
	}
	V ans = vi;
	for(int i = m; i >= 0; i -= 2) if(i <= siz[1]) ans = min(ans, dp[1][i]);
	for(int i: ans) printf("%d ", i);
	puts("");
}


//count how many S\in {1....n} satisfied: u,v\in S,(u+v)/2 \in S,(u+v)%2==0
#include<bits/stdc++.h>
#define mod 998244353
using namespace std;
int cal3(int n){
	int ans=0;
	for(int i=1,pos;i<=n;i=pos+1){
		pos=n/(n/i);
		int z=n/i;
		int l=i%2==0?i+1:i,r=pos%2==0?pos-1:pos;
		int a=(r-l+2)/2,b=1ll*a*(l+r)/2%mod;
		ans=(ans-1ll*z*b-1ll*z*z%mod*b+2ll*z*n%mod*a)%mod;
	}
	ans=(ans%mod+mod)%mod;
	ans=(1ll*ans*(mod+1)/2+n+1)%mod; 
	return ans;
}
int main(){
	int n;
	scanf("%d",&n);
	printf("%d",cal3(n));
} 

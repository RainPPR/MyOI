#include<bits/stdc++.h>
using namespace std;
const int N=1010;
int read(){
	char x=0;while(x<'A'||x>'Z')x=getchar();
	if(x=='Y')return 1;if(x=='K')return 2;return 0;
}
int ch[N],sz[3];
// std::vector<std::vector<std::vector<std::vector<int>>>> f;

int *f;

vector<int> pos[3];
int n;
int cnt[N][3];
int main()
{
	scanf("%d",&n);
	// std::cerr << n << std::endl;
	cnt[0][0]=cnt[0][1]=cnt[0][2]=0;
	for(int i=1;i<=n;i++){
		ch[i]=read();
		pos[ch[i]].push_back(i);
		sz[ch[i]]++;
		for(int j=0;j<3;j++)
			cnt[i][j]=cnt[i-1][j];
		cnt[i][ch[i]]++;
	}
	// std::cerr << "read" << std::endl;
	f = new int[2 * (sz[1] + 1) * (sz[2] + 1) * 2];
	const int v0 = (sz[1] + 1) * (sz[2] + 1) * 2;
	const int v1 = (sz[2] + 1) * 2;
	const int v2 = 2;
	// f.resize(sz[0]+1, vector<vector<vector<int>>>(sz[1]+1, vector<vector<int>>(sz[2]+1, vector<int>(2, 0x3f3f3f3f))));
	for(int i=0;i<=1;i++)
		for(int j=0;j<=sz[1];j++)
			for(int k=0;k<=sz[2];k++)
				f[i * v0 + j * v1 + k * v2 + 0]=f[i * v0 + j* v1 + k * v2 + 1]=0x3f3f3f3f;
	f[0]=0;
	for(int i=0;i<=sz[0];i++)for(int j=0;j<=sz[1];j++)for(int k=0;k<=sz[2];k++)if(i||j||k){
		// std::cerr << i << " " << j << " " << k << std::endl;
		//others
		int s = (i&1) * v0 + j * v1 + k * v2;
		int _v0 = (i & 1) ? -v0 : v0;
		if(i){
			int t=pos[0][i-1],cnt=0;
			cnt = max(0, ::cnt[t][0] - i) + max(0, ::cnt[t][1] - j) + max(0, ::cnt[t][2] - k);
			f[s]=min(f[s + _v0 + 0]+cnt, f[s + _v0 + 1]+cnt);
			f[s + 1] = 0x3f3f3f3f;
		}
		//Y
		if(j){
			int t=pos[1][j-1],cnt=0;
			cnt = max(0, ::cnt[t][0] - i) + max(0, ::cnt[t][1] - j) + max(0, ::cnt[t][2] - k);
			f[s + 1]=min(f[s - v1 + 0]+cnt, f[s - v1 + 1]+cnt);
		}
		//K
		if(k){
			int t=pos[2][k-1],cnt=0;
			cnt = max(0, ::cnt[t][0] - i) + max(0, ::cnt[t][1] - j) + max(0, ::cnt[t][2] - k);
			f[s + 0]=min(f[s - v2 + 0]+cnt ,f[s + 0]);
		}
		// std::cerr << f[s + 0] << " " << f[s + 1] << std::endl;
	}
	int s = (sz[0]&1) * v0 + sz[1] * v1 + sz[2] * v2;
	cout<<
	min(f[s + 0],
	f[s + 1])
	<<endl;
}

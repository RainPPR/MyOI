#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll N = 5e6+5;
ll lft, rgt, n, r;
ll tot, a[N];
const ll inf  = 1e18;
ll ans = 1e18;

inline void check1(ll i){
	if(i < lft || i > rgt || i % 2 != lft % 2)return;
	ll sz1 = (r - 3) / 2, sz2 = r / 2;
	ll a = i, b = (tot - 3ll*i) / 2;
	ans = min(ans, a + (max(0ll,b - a*sz1) + sz2 - 1) / sz2);
}

int main()
{
	// freopen("input.txt","r",stdin);
	// freopen("output.txt","w",stdout);
	cin >> n >> r;
//	std::cerr << n << " " << r << std::endl;
	// n=2000, r = 1999;
	for(ll i=1;i<=n;i++){
		// a[i] = 2000;
		scanf("%lld",&a[i]);
		tot+=a[i];
		if(a[i]%2){
			lft++;a[i]-=3;
		}
		rgt+=(a[i]/6)*2;
	}
	rgt+=lft;
	ll sz1 = (r - 3) / 2, sz2 = r / 2;
	// std::cerr << r << " " << sz1 << " " << sz2<< std::endl;
	for(ll i=lft;i<=lft;i+=2){
		ll a = i, b = (tot - 3*i) / 2;
		ans = min(ans, a + (max(0ll,b - a*sz1) + sz2 - 1) / sz2);
		// if(a + (max(0,b - a*sz1) + sz2 - 1) / sz2==2001){
		// 	// cout << i << ":" << a + (max(0,b - a*sz1) + sz2 - 1) / sz2 << endl;
		// }
	}
	// cerr << "?" << std::endl;
	// cerr << ans << endl;
	ll ql = lft, qr = rgt;
	ql/=2, qr/=2;
	while(ql<qr){
		ll mid = (ql+qr+1)>>1;
		ll i = mid*2 + lft%2;
		ll a = i, b = (tot - 3ll*i) / 2;
		if(b - a*sz1 >= 0){
			ql=mid;
		}else qr=mid-1;
	}
	// cout << l << endl;
	check1(ql * 2 + lft%2);
//	check1(ql * 2 + lft%2 + 2);

	// cout << lft << ":" << rgt << endl;
	ll maxdec = r / 3;
	ll need2 = (tot - 3*lft) / 2;
	// cerr << ans << endl;
	for(ll i=0;i<=lft;i++)if(((lft-i)%2==0)){
		// cout << i << ":" << endl;
		ll sum = (lft - i) / 2;
		ll rest = i * (maxdec - 1)/2;
		ll s1 = r - 3  - (r-3)%2;
		ll s2 = r - (r%2);
		// cout << s1 << ": " << s2 << endl;
		if(rest >= sum){
			ll ss = s1 * i - 3*(lft-i);
			// cout << r << ":" << s2 << endl;
			// return 0;
			ll add = max(0ll, (need2*2-ss+s2-1)/s2);
			ans = min(ans, add + i);
		}else{
			ll once = maxdec/2;
			// cout << once << endl;
			if(once == 0)continue;
			ll add1 = (sum-rest+once-1)/once;
			ll ss = s1 * i + add1 * s2 - 3ll*(lft-i);
			ll add2 = max(0ll, (need2 * 2ll - ss + s2 - 1ll) / s2);
			ans = min(ans, add1 + add2 + i);
		}
		// cout << "fin" << endl;
	}
	cout << ans << endl;
	// if(ans == (tot-1)/r+1)return 1;
}
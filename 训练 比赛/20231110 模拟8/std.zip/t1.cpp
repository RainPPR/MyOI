#include<bits/stdc++.h>
using namespace std;
int n,m,r,v;

int main()
{
	cin >> n >> m >> r >> v;
	long long ans = (n * 1000000ll + m) / r;
	for(int j=1;j<=1000000;j++){
		int rest = 1ll*j*r%1000000;
		if(rest > m && rest + v < 1000000){
			cout << min(1ll*j - 1,ans) << endl;
			return 0;
		}
	}
	cout << ans << endl;
	return 0;
}

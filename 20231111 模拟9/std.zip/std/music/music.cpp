#include<iostream>
#include<algorithm>
#include<cstring>
#include<cstdio>
#include<bitset>
#include<random>
#include<cmath>
#include<ctime>
#include<queue>
#include<map>
#include<set>

#define fi first
#define se second
#define max Max
#define min Min
#define abs Abs
#define lc (x<<1)
#define rc (x<<1|1)
#define mid ((l+r)>>1)
#define pb(x) push_back(x)
#define lowbit(x) ((x)&(-(x)))
#define fan(x) ((((x)-1)^1)+1)
#define mp(x,y) make_pair(x,y)
#define clr(f,n) memset(f,0,sizeof(int)*(n))
#define cpy(f,g,n) memcpy(f,g,sizeof(int)*(n))
#define SZ(x) ((int)(x.size()))
#define INF 0x3f3f3f3f

using namespace std;

inline int read()
{
	int ans=0,f=1;
	char c=getchar();
	while(c>'9'||c<'0'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9'){ans=(ans<<1)+(ans<<3)+c-'0';c=getchar();}
	return ans*f;
}

inline void write(int x)
{
	if(x<0) putchar('-'),x=-x;
	if(x/10) write(x/10);
	putchar((char)(x%10)+'0');
}

template<typename T>inline T Abs(T a){return a>0?a:-a;};
template<typename T,typename TT>inline T Min(T a,TT b){return a<b?a:b;}
template<typename T,typename TT> inline T Max(T a,TT b){return a<b?b:a;}

const int N=405,M=5e3+5;
int n,m,a[N],b[N],cnt[M];

signed main()
{
	freopen("music.in","r",stdin);
	freopen("music.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=n;++i)
		a[i]=read();
	for(int i=1;i<=n;++i)
		b[i]=read();
	for(int i=n+1;i<=n*2;++i)
		a[i]=a[i-n],b[i]=b[i-n];
	int ans=0;
	for(int l=1;l<=n+1;++l)
	{
		memset(cnt,0,sizeof(cnt));
		for(int j=n;j>=l;--j)
		{
			int now=a[j],res=0;
			while(now>0&&res<m)
				++cnt[now],now-=b[j],res++;
		}
		for(int r=n+1;r<l+n;++r)
		{
			int now=a[r],res=0;
			while(now>0&&res<m)
				++cnt[now],now-=b[r],++res;
			int lst=m-(n+1-l)-(r-(n+1))-min((n+1)-l,r-(n+1));
			if(lst<0) break;res=0;
			for(int k=5000;k>=0;--k)
			{
				for(int j=1;j<=cnt[k];++j)
				{
					if(lst>0) --lst,res+=k;
					else break;
				}
				if(lst<=0) break;
			}
			ans=max(ans,res);
		}
	}
	write(ans);puts("");
	return 0;
}

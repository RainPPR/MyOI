#include<iostream>
#include<algorithm>
#include<cstring>
#include<cstdio>
#include<bitset>
#include<random>
#include<cmath>
#include<ctime>
#include<queue>
#include<map>
#include<set>

#define int long long
#define fi first
#define se second
#define max Max
#define min Min
#define abs Abs
#define lc ch[x][0]
#define rc ch[x][1]
#define mid ((l+r)>>1)
#define pb(x) push_back(x)
#define lowbit(x) ((x)&(-(x)))
#define fan(x) ((((x)-1)^1)+1)
#define mp(x,y) make_pair(x,y)
#define clr(f,n) memset(f,0,sizeof(int)*(n))
#define cpy(f,g,n) memcpy(f,g,sizeof(int)*(n))
#define SZ(x) ((int)(x.size()))
#define INF 0x3f3f3f3f

using namespace std;

inline int read()
{
	int ans=0,f=1;
	char c=getchar();
	while(c>'9'||c<'0'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9'){ans=(ans<<1)+(ans<<3)+c-'0';c=getchar();}
	return ans*f;
}

inline void write(int x)
{
	if(x<0) putchar('-'),x=-x;
	if(x/10) write(x/10);
	putchar((char)(x%10)+'0');
}

template<typename T>inline T Abs(T a){return a>0?a:-a;};
template<typename T,typename TT>inline T Min(T a,TT b){return a<b?a:b;}
template<typename T,typename TT> inline T Max(T a,TT b){return a<b?b:a;}

const int N=1e5+5,K=10,mod=998244353;
int n,m,Tag,k,l,r,siz[N],rt[N],w[K][K],w2[K],son[N],id[N],Ans,du[N];
bool vis[K];

inline int MOD(int x)
{
	return x>=mod?x-mod:x;
}

struct State
{
	int mch[K];
}now;

vector<State> state[K];

void dfs(int u,int len)
{
	if(u==len+1)
	{
		memset(vis,0,sizeof(vis));
		int flag=1;
		for(int i=1;i<=len;++i)
			if(now.mch[i])
			{
				flag&=(!vis[now.mch[i]]);
				flag&=(!now.mch[now.mch[i]]);
				vis[now.mch[i]]=1;
			}
		if(flag)
		{
			State tmp=now;
			for(int i=1;i<=len;++i)
				if(tmp.mch[i]>0)
					tmp.mch[tmp.mch[i]]=-1;
			state[len].push_back(tmp);
		}
		return;
	}
	dfs(u+1,len);
	for(int i=u+1;i<=len;++i)
	{
		now.mch[u]=i;
		dfs(u+1,len);
		now.mch[u]=0;
	}
}

struct Edge
{
	int v,w,ne;
}e[N*2];
int head[N],tot;

inline void add(int u,int v,int w)
{
	e[++tot]=(Edge){v,w,head[u]};
	head[u]=tot;
}

inline bool cmp(int x,int y)
{
	return siz[x]<siz[y];
}

mt19937 rd(114514); 

struct FHQ
{
	int v1[N*50],v2[N*50],v3[N*50],val[N*50],tg[N*50],tg2[N*50],ch[N*50][2],cnt;
	inline void pushup(int x){val[x]=MOD(MOD(val[lc]+val[rc])+v3[x]);}
	inline void upd(int x,int v){if(!x) return;v1[x]=(v1[x]+v)%m,tg[x]=(tg[x]+v)%m;}
	inline void upd2(int x,int v){if(!x) return;v3[x]=v3[x]*v%mod,val[x]=val[x]*v%mod,tg2[x]=tg2[x]*v%mod;}
	inline void pushdown(int x)
	{
		if(!x) return;
		if(tg[x]) upd(lc,tg[x]),upd(rc,tg[x]),tg[x]=0;
		if(tg2[x]!=1) upd2(lc,tg2[x]),upd2(rc,tg2[x]),tg2[x]=1;
	}
	inline int New(int V1,int V2)
	{
		v2[++cnt]=rd();
		v1[cnt]=V1;v3[cnt]=V2;val[cnt]=V2;
		tg[cnt]=0;tg2[cnt]=1;
		ch[cnt][0]=ch[cnt][1]=0;
		return cnt;
	}
	void split(int x,int k,int &a,int &b)
	{
		if(!x) a=b=0;
		else
		{
			pushdown(x);
			if(v1[x]<=k)
				a=x,split(rc,k,rc,b);
			else b=x,split(lc,k,a,lc);
			pushup(x);
		}
	}
	int merge(int x,int y)
	{
		if(!x||!y) return x+y;
		pushdown(x);pushdown(y);
		if(v2[x]<v2[y])
		{
			ch[x][1]=merge(ch[x][1],y);
			pushup(x);return x;
		}
		else
		{
			ch[y][0]=merge(x,ch[y][0]);
			pushup(y);return y;
		}
	}
	inline void add(int &rt,int p,int v)
	{
		if(!v) return;
		int a=0,b=0,c=0;
		split(rt,p,b,c);
		if(p) split(b,p-1,a,b);
		if(!b) b=New(p,v);
		else
		{
			v3[b]=MOD(v3[b]+v);
			val[b]=MOD(val[b]+v);
		}
		rt=merge(merge(a,b),c);
	}
	inline int query(int &rt,int l,int r)
	{
		if(l>r) return 0;
		int a=0,b=0,c=0;
		split(rt,r,b,c);
		if(l) split(b,l-1,a,b);
		int res=val[b];
		rt=merge(merge(a,b),c);
		return res;
	}
	void print(int x)
	{
		if(!x) return;
		pushdown(x);
		print(lc);
		printf("%d %d\n",v1[x],v3[x]);
		print(rc);
	}
	inline void move(int &rt,int x)
	{
		x%=m;
		if(!x) return;
		int a=0,b=0;
		split(rt,m-x-1,a,b);
		upd(a,x);upd(b,x-m);
		rt=merge(b,a);
	}
	int Query(int x,int &rt)
	{
		if(!x) return 0;
		pushdown(x);int res=0;
		int L=max(l-v1[x],0ll),R=min(r-v1[x],m-v1[x]-1);
		res=(res+query(rt,L,R)*v3[x])%mod;
		L=max(l+m-v1[x],m-v1[x]);R=min(r+m-v1[x],m-1);
		res=(res+query(rt,L,R)*v3[x])%mod;
		res=MOD(res+Query(lc,rt));
		res=MOD(res+Query(rc,rt));
		return res;
	}
	void Update(int x,int &rt,int v)
	{
		if(!x) return;
		pushdown(x);
		add(rt,v1[x],v3[x]*v%mod);
		Update(lc,rt,v);
		Update(rc,rt,v);
	}
}fhq;

int Dfs(int u,int fa)
{
	siz[u]++;
	int is_leaf=1;
	for(int i=head[u];i;i=e[i].ne)
	{
		int v=e[i].v;
		if(v==fa) continue;
		int tmp=Dfs(v,u);
		siz[u]+=siz[v];
		if(Tag) e[i].w=(e[i].w^tmp)%m;
		fhq.move(rt[v],e[i].w);
		is_leaf=0;
	}
	if(is_leaf)
	{
		rt[u]=fhq.New(0,1);
		return 1;
	}
	int mm=0;
	for(int i=head[u];i;i=e[i].ne)
	{
		int v=e[i].v;
		if(v==fa) continue;
		son[++mm]=v;
	}
	sort(son+1,son+1+mm,cmp);
	
	for(int i=1;i<=mm;++i)
		for(int j=i+1;j<=mm;++j)
			w[i][j]=fhq.Query(rt[son[i]],rt[son[j]]);
	for(int i=1;i<=mm;++i)
		w2[i]=fhq.query(rt[son[i]],l,r);
	// up
	if(u!=1)
	{
		for(int i=mm;i>=1;--i)
		{
			int nm=0,val=0;
			for(int j=1;j<=mm;++j)
				if(j!=i) id[++nm]=j;
			for(auto j:state[mm-1])
			{
				int tmp=1;
				for(int k=1;k<=mm-1;++k)
					if(j.mch[k]==0)
						tmp=tmp*w2[id[k]]%mod;
					else if(j.mch[k]!=-1)
						tmp=tmp*w[id[k]][id[j.mch[k]]]%mod;
				val=MOD(val+tmp);
			}
			if(i==mm)
			{
				rt[u]=rt[son[i]];
				fhq.upd2(rt[u],val);
			}
			else fhq.Update(rt[son[i]],rt[u],val);
		}	
	} 
	// no up
	int val=0;
	for(auto j:state[mm])
	{
		int tmp=1;
		for(int k=1;k<=mm;++k)
			if(j.mch[k]==0)
				tmp=tmp*w2[k]%mod;
			else if(j.mch[k]!=-1)
				tmp=tmp*w[k][j.mch[k]]%mod;
		val=(val+tmp)%mod;
	}
	fhq.add(rt[u],0,val);
	return val;
}

signed main()
{
	freopen("problem.in","r",stdin);
	freopen("problem.out","w",stdout);
	n=read();m=read();k=read();Tag=read();
	l=read();r=read();
	for(int i=1;i<n;++i)
	{
		int u=read(),v=read(),w=read();
		add(u,v,w);add(v,u,w);
		du[u]++;du[v]++;
	}
	for(int i=0;i<=k;++i)
		dfs(1,i);
	Ans=Dfs(1,0);
	write(Ans);
	return 0;
}

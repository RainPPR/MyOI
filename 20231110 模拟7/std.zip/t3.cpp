#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int mod=1e9+7;
inline int add(int a,int b){a+=b;return a>=mod?a-mod:a;}
inline int sub(int a,int b){a-=b;return a<0?a+mod:a;}
inline int mul(int a,int b){return (ll)a*b%mod;}
inline int qpow(int a,int b){int ret=1;for(;b;b>>=1,a=mul(a,a))if(b&1)ret=mul(ret,a);return ret;}
/* math */
int n;double pp[10];
int p[10];
map<vector<int>, int> mp;
const int N = 510;
vector<int> make(vector<int> x){
	vector<int> ret(0,0);
	for(int i=0;i<n-1;i++){
		ret.push_back(x[i+1]-x[i]);
	}
	return ret;
}
int id=0;
inline void dfs(int x,vector<int> d){
	if(x>=n+2){
		vector<int> tar=make(d);
		mp[tar]=1;
		return ;
	}
	vector<int> t(n,0);
	for(int i=0;i<n;i++){
		for(int j=i-1;j<=i+1;j++){
			if(j<0||j>=n)continue;
			t[i]=max(t[i],d[j]);
		}
	}
	for(int i=0;i<n;i++){
		t[i]++;
		dfs(x+1,t);
		t[i]--;
	}
}
int f[N+1][N+1];
int P[N];
inline void make(int x,vector<int> sum){
	vector<int> d(n,0);
	d[0]=0;
	int mx=0;
	for(int i=1;i<n;i++)d[i]=d[i-1]+sum[i-1],mx=max(mx,d[i]);
	vector<int> t(n,-100);
	for(int i=0;i<n;i++){
		for(int j=i-1;j<=i+1;j++){
			if(j<0||j>=n)continue;
			t[i]=max(t[i],d[j]);
		}
	}
	f[x][x]=add(f[x][x],1);
	f[id+1][x]=add(f[id+1][x],1);
	for(int i=0;i<n;i++){
		t[i]++;
		if(t[i]>mx){
			P[x]=add(P[x],p[i+1]);
			// cout << x << " " << P[x] << " " << i << endl;
		}
		vector<int> tar=make(t);
		int nxt=mp[tar];
		f[nxt][x]=sub(f[nxt][x],p[i+1]);
		t[i]--;
	}
}

int ans=0;

inline void gauss(int n,int m){
	// for(int i=1;i<=n;i++){
	// 	for(int j=1;j<=n;j++){
	// 		cout << f[i][j] << " ";
	// 	}
	// 	puts("");
	// }
	for(int i=1;i<=m;i++){
		int pos=0;
		for(int j=i;j<=n;j++)
			if(f[j][i])pos=j;
		for(int k=1;k<=m+1;k++)
			swap(f[i][k],f[pos][k]);
		int inv=qpow(f[i][i],mod-2);
		for(int j=i+1;j<=n;j++)if(f[j][i]){
			int c=mul(f[j][i],inv);
			for(int d=i;d<=m+1;d++){
				f[j][d]=sub(f[j][d], mul(c,f[i][d]));
			}
		}
	}
	for(int i=m;i;i--){
		int inv=qpow(f[i][i],mod-2);
		for(int j=i-1;j;j--)if(f[j][i]){
			int c=mul(f[j][i],inv);
			for(int d=i;d<=m+1;d++){
				f[j][d]=sub(f[j][d], mul(c,f[i][d]));
			}
		}
	}
	for(int i=1;i<=m;i++){
		ans=add(ans,mul(P[i], mul(f[i][m+1],qpow(f[i][i],mod-2))));
	}
}

int main()
{
//	freopen("a.in","r",stdin);
//	freopen("a.out","w",stdout);
	cin >> n;
	for(int i=1;i<=n;i++)scanf("%lf",&pp[i]);
	for(int i=1;i<=n;i++)p[i]=mul(pp[i]*100+0.00001, qpow(100,mod-2));
	dfs(1,vector<int>(n,0));
	if(n==2)puts("1");
	else{
		map<vector<int>,int>::iterator itt;
		for(itt=mp.begin();itt!=mp.end();itt++){
			mp[(*itt).first] = ++id;
		}
		for(itt=mp.begin();itt!=mp.end();itt++){
			make((*itt).second,(*itt).first);
		}
		f[id+1][id+1]=1;
		gauss(id+1,id);
		cout << ans << endl;
	}
}

#include <bits/stdc++.h>
const int N = 1e5+5;
int par[N], n;
int fa[N], val[N], a[N], b[N];
std::vector<int> to[N];
int f[N];
class node {
public:
  int x, y;
  node(int x = 0, int y = 0): x(x), y(y) {}
  node operator - (node nd) {
    return node(x - nd.x, y - nd.y);
  }
  long long operator * (node nd) {
    return 1ll * x * nd.y - 1ll * y * nd.x;
  }
};

class convex_hull {
public:
  node v[N];
  int top{0};
}cvh;
std::stack < std::pair<int,node> > chgs;

inline void dfs(int x,int dep) {
  // std::cerr << x << ":" << cvh.top << std::endl;
  // for(size_t i = 1; i <= cvh.top; i ++) {
  //   std::cerr << cvh.v[i].x << " " << cvh.v[i].y << ", " << std::endl;
  // }
  if(x != 1) {
    node cur(dep, val[x]);
    node v(1, a[x]);
    int l = 1, r = cvh.top;
    while(l < r) {
      int mid = (l + r) / 2;
      if((cvh.v[mid + 1] - cvh.v[mid]) * v >= 0) {
        l = mid + 1;
      } else {
        r = mid;
      }
    }
    // std::cerr << x << " update from " << l << " " << cvh.v[l].x << " " << cvh.v[l].y << std::endl;
    f[x] = cvh.v[l].y + (dep - cvh.v[l].x) * a[x] + b[x];
    node insnd(dep, f[x]);
    while(cvh.top > 1 && (cvh.v[cvh.top] - cvh.v[cvh.top - 1]) * (insnd - cvh.v[cvh.top - 1]) < 0) {
      cvh.top --;
    }
    // std::cerr << cvh.top + 1 << " " << insnd.x << " " << insnd.y << std::endl;
    chgs.push(std::make_pair(cvh.top + 1, cvh.v[cvh.top + 1]));
    cvh.v[++cvh.top] = insnd;
  } else {
    f[x] = 0;
    cvh.top = 1;
    chgs.push(std::make_pair(cvh.top, node(0, 0)));
    cvh.v[1] = node(0, 0);
  }
  int curtop = cvh.top;
  for(auto v : to[x]) {
    cvh.top = curtop;
    dfs(v, dep + 1);
  }
  auto top = chgs.top();
  cvh.v[top.first] = top.second;
  chgs.pop();
}


int main() {
  std::cin >> n;
  for(size_t i = 2; i <= n; i ++) {
    scanf("%d", &fa[i]);
    scanf("%d%d", &a[i], &b[i]);
    to[fa[i]].push_back(i);
  }
  dfs(1, 0);
  for(size_t i = 1; i <= n; i ++) {
    printf("%d%c", f[i], i == n ? '\n' : ' ');
  }
  // printf("\n");
}
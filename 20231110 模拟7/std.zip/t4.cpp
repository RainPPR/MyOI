#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int mod = 998244353;
inline int add(int a,int b){a+=b;return a>=mod?a-mod:a;}
inline int sub(int a,int b){a-=b;return a<0?a+mod:a;}
inline int mul(int a,int b){return 1ll*a*b%mod;}
inline int qpow(int a,int b){int ret=1;for(;b;b>>=1,a=mul(a,a))if(b&1)ret=mul(ret,a);return ret;}
/* math */
const int N = 2e6+5;
int a[N], n, t;

int main()
{
	cin >> n >> t;
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		t-=a[i];
		if(t<0){
			puts("0");
			return 0;
		}
	}
	int fir = t+n+a[1];
	int ans = 1;
	for(int i=2;i<=n;i++){
		// cout << fir << "?" << endl;
		ans = mul(ans, fir);
		fir += a[i];fir-=1;
		fir%=mod;
	}
	printf("%d\n", mul(ans, t+1));
}

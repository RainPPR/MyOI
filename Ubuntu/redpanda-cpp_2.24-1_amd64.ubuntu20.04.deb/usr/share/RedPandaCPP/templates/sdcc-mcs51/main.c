#include <8051.h>

void main(void) {
	for(;;) {
		P1--;
	}
}